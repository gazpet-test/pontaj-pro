// ════════════════════════════════════════════════════════════════════════════
// MODULUL LOGISTICĂ — v2.0 (Pasul B: Edit + Create)
// ════════════════════════════════════════════════════════════════════════════

import { useState, useEffect, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from './lib/supabase.js'
import * as XLSX from 'xlsx-js-style'
import ServiceTab from './ServiceTab.jsx'

// ─── Theme ───────────────────────────────────────────────────────────────────
const G = {
  bg:'#0D1117', surface:'#161B22', border:'#21262D', border2:'#30363D',
  text:'#E6EDF3', muted:'#8B949E', dim:'#6E7681',
  blue:'#58A6FF', green:'#3FB950', red:'#F85149', yellow:'#D29922',
  purple:'#BC8CFF', orange:'#F0883E',
  greenDim:'#1A3A1A', redDim:'#3A1A1A', yellowDim:'#3A2A0A',
  logistica:'#E3B341',
}
const S = {
  page: { fontFamily:"'Syne','Barlow',sans-serif", background:G.bg, minHeight:'100vh', color:G.text },
  card: { background:G.surface, border:`1px solid ${G.border}`, borderRadius:12 },
  input: { background:G.bg, border:`1px solid ${G.border2}`, color:G.text, borderRadius:8, padding:'8px 12px', fontFamily:'inherit', fontSize:14, outline:'none', width:'100%' },
  btnP: { background:'#1F6FEB', color:'white', border:'none', borderRadius:8, padding:'9px 18px', fontFamily:'inherit', fontSize:14, fontWeight:700, cursor:'pointer' },
  btnS: { background:G.surface, color:G.text, border:`1px solid ${G.border}`, borderRadius:8, padding:'7px 14px', fontFamily:'inherit', fontSize:13, fontWeight:600, cursor:'pointer' },
}

const STARI = ['Functional', 'Nefunctional', 'In_service']
const TIPURI_CARBURANT = ['', 'motorina', 'benzina', 'electric', 'gpl', 'mixt']
const FIRME = ['Gazpet Instal', 'Gazpet Invest', 'Alt proprietar']
const UNITATI_NORMA = ['l/h', 'l/100km']

const daysUntil = (d) => d ? Math.ceil((new Date(d) - new Date()) / 86400000) : null
const fmtDate = (d) => d ? new Date(d).toLocaleDateString('ro-RO', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '—'

// ─── Toast ───────────────────────────────────────────────────────────────────
function useToast() {
  const [toast, setToast] = useState(null)
  const show = (msg, type='success') => { setToast({ msg, type }); setTimeout(() => setToast(null), 3500) }
  return [toast, show]
}
function Toast({ toast }) {
  if (!toast) return null
  const colors = { success:G.green, error:G.red, warn:G.orange }
  return <div className="toast" style={{
    background: colors[toast.type] + '22',
    border: `1px solid ${colors[toast.type]}55`,
    color: colors[toast.type]
  }}>{toast.msg}</div>
}

// ─── Badges ──────────────────────────────────────────────────────────────────
function StareBadge({ stare }) {
  const cfg = {
    'Functional': { bg: G.green+'22', color: G.green, label: '✓ Funcțional' },
    'Nefunctional': { bg: G.red+'22', color: G.red, label: '✗ Nefuncțional' },
    'In_service': { bg: G.yellow+'22', color: G.yellow, label: '🔧 În service' },
    'Service': { bg: G.yellow+'22', color: G.yellow, label: '🔧 În service' },
  }
  const c = cfg[stare] || { bg: G.dim+'22', color: G.dim, label: stare || '—' }
  return <span style={{display:'inline-block',padding:'3px 10px',borderRadius:12,fontSize:11,fontWeight:700,letterSpacing:'.3px',background:c.bg,color:c.color}}>{c.label}</span>
}

function MentenantaScadenta({ data, ore }) {
  if (!data && !ore) return <span style={{color: G.dim, fontSize: 12}}>—</span>
  const days = daysUntil(data)
  let color = G.muted, prefix = ''
  if (days !== null) {
    if (days < 0) { color = G.red; prefix = '⚠️ ' }
    else if (days <= 7) { color = G.red; prefix = '🔴 ' }
    else if (days <= 30) { color = G.orange; prefix = '🟠 ' }
    else if (days <= 60) { color = G.yellow; prefix = '🟡 ' }
    else { color = G.green; prefix = '🟢 ' }
  }
  return (
    <div style={{fontSize: 12, color, lineHeight: 1.4}}>
      {data && <div style={{fontWeight: 600}}>{prefix}{fmtDate(data)}{days !== null && days >= 0 && days <= 90 && ` (${days}z)`}</div>}
      {ore && <div style={{fontSize: 11, color: G.muted}}>{ore.toLocaleString('ro-RO')} ore</div>}
    </div>
  )
}

function KPICard({ icon, label, value, color = G.blue, sub }) {
  return (
    <div style={{...S.card, padding: '14px 18px', flex: 1, minWidth: 160, borderLeft: `3px solid ${color}`}}>
      <div style={{fontSize: 11, color: G.muted, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.5px', marginBottom: 4}}>{icon} {label}</div>
      <div style={{fontSize: 24, fontWeight: 800, color: G.text, fontVariantNumeric: 'tabular-nums'}}>{value}</div>
      {sub && <div style={{fontSize: 11, color: G.muted, marginTop: 2}}>{sub}</div>}
    </div>
  )
}

// ─── Card statistici per perioadă (azi/săptămână/lună alimentări) ────────────
function PerioadaCard({ label, data, suffix, color }) {
  const litri = Number(data[`litri_${suffix}`] || 0)
  const utilaje = Number(data[`utilaje_${suffix}`] || 0)
  const alim = Number(data[`alim_${suffix}`] || 0)
  const cost = Number(data[`cost_${suffix}`] || 0)
  return (
    <div style={{...S.card, padding: '12px 16px', flex: 1, minWidth: 220, borderTop: `3px solid ${color}`}}>
      <div style={{fontSize: 11, color: G.muted, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.5px', marginBottom: 8}}>
        {label}
      </div>
      <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10}}>
        <div>
          <div style={{fontSize: 10, color: G.muted, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.3px'}}>Motorină</div>
          <div style={{fontSize: 19, fontWeight: 800, color, fontVariantNumeric: 'tabular-nums'}}>
            {litri.toLocaleString('ro-RO', {minimumFractionDigits: 0, maximumFractionDigits: 1})} <span style={{fontSize: 11, color: G.muted, fontWeight: 600}}>L</span>
          </div>
        </div>
        <div>
          <div style={{fontSize: 10, color: G.muted, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.3px'}}>Utilaje / Alim.</div>
          <div style={{fontSize: 19, fontWeight: 800, color: G.text, fontVariantNumeric: 'tabular-nums'}}>
            {utilaje} <span style={{fontSize: 11, color: G.muted, fontWeight: 600}}>/ {alim}</span>
          </div>
        </div>
      </div>
      {cost > 0 && (
        <div style={{marginTop: 6, paddingTop: 6, borderTop: `1px solid ${G.border}`, display: 'flex', justifyContent: 'space-between', fontSize: 11}}>
          <span style={{color: G.muted}}>💰 Cost</span>
          <strong style={{color: G.green, fontVariantNumeric: 'tabular-nums'}}>{cost.toLocaleString('ro-RO', {minimumFractionDigits: 2, maximumFractionDigits: 2})} RON</strong>
        </div>
      )}
    </div>
  )
}

// ─── Sortable header cell ────────────────────────────────────────────────────
function SortableTh({ col, sortBy, setSortBy, width, children }) {
  const isActive = sortBy.col === col
  const handleClick = () => {
    if (isActive) setSortBy({ col, dir: sortBy.dir === 'asc' ? 'desc' : 'asc' })
    else setSortBy({ col, dir: 'asc' })
  }
  return (
    <th onClick={handleClick} style={{
      width, cursor: 'pointer', userSelect: 'none',
      color: isActive ? G.logistica : undefined
    }}>
      <span style={{display:'inline-flex', alignItems:'center', gap:4}}>
        {children}
        <span style={{fontSize: 9, opacity: isActive ? 1 : .35}}>
          {isActive ? (sortBy.dir === 'asc' ? '▲' : '▼') : '▲▼'}
        </span>
      </span>
    </th>
  )
}

// ─── Form Field components ───────────────────────────────────────────────────
const FieldLabel = ({ label, required }) => (
  <div style={{fontSize: 11, color: G.muted, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.5px', marginBottom: 5}}>
    {label} {required && <span style={{color: G.red}}>*</span>}
  </div>
)

function FieldText({ label, value, onChange, required, placeholder, type='text', readonly }) {
  return (
    <div>
      <FieldLabel label={label} required={required} />
      <input type={type} value={value || ''} onChange={e => onChange(e.target.value)} placeholder={placeholder} readOnly={readonly}
        style={{...S.input, background: readonly ? G.surface : G.bg, color: readonly ? G.muted : G.text}} />
    </div>
  )
}

function FieldSelect({ label, value, onChange, options, required, readonly, placeholder }) {
  return (
    <div>
      <FieldLabel label={label} required={required} />
      <select value={value || ''} onChange={e => onChange(e.target.value)} disabled={readonly}
        style={{...S.input, padding: '7px 11px', fontSize: 13, background: readonly ? G.surface : G.bg, color: readonly ? G.muted : G.text, cursor: readonly ? 'default' : 'pointer'}}>
        {placeholder && <option value="">{placeholder}</option>}
        {options.map((o, i) => (
          typeof o === 'object' && o !== null
            ? <option key={`${o.value}-${i}`} value={o.value}>{o.label}</option>
            : <option key={`${o}-${i}`} value={o}>{o || '— niciuna —'}</option>
        ))}
      </select>
    </div>
  )
}

function FieldTextarea({ label, value, onChange, rows=2, readonly, mono }) {
  return (
    <div>
      <FieldLabel label={label} />
      <textarea value={value || ''} onChange={e => onChange(e.target.value)} rows={rows} readOnly={readonly}
        style={{...S.input, fontFamily: mono ? 'monospace' : 'inherit', fontSize: mono ? 12 : 14, background: readonly ? G.surface : G.bg, color: readonly ? G.muted : G.text, resize: 'vertical', wordBreak: mono ? 'break-all' : 'normal'}} />
    </div>
  )
}

// ─── Modal Alimentare Combustibil ────────────────────────────────────────────
const STATII = ['', 'Gazpet - Oscar (vrac propriu)', 'Petrom', 'OMV', 'MOL', 'Rompetrol', 'Lukoil', 'Gazprom', 'Socar', 'Tinmar', 'Altele']
const STATIE_GAZPET = 'Gazpet - Oscar (vrac propriu)'  // identifier pentru detectare

function AlimentareModal({ activ, onClose, onSaved, showToast, rezervorGazpet, sites, pretMotorina }) {
  const [form, setForm] = useState({
    data_alimentare: new Date().toISOString().split('T')[0],
    cantitate_litri: '',
    ore_la_alimentare: '',
    km_la_alimentare: '',
    ore_lucrate_efectiv: '',
    statie_combustibil: '',
    card_combustibil: '',
    pret_total: '',
    pret_per_litru: '',
    numar_factura: '',
    observatii: '',
    site_id: '',
  })
  const [saving, setSaving] = useState(false)
  const [lastEdited, setLastEdited] = useState(null)  // 'total' | 'pret' | null
  const [pretMediuGazpet, setPretMediuGazpet] = useState(null)
  const setField = (k, v) => setForm(p => ({ ...p, [k]: v }))
  
  const isGazpet = form.statie_combustibil === STATIE_GAZPET
  const stocCurent = rezervorGazpet?.stoc_curent_litri ? Number(rezervorGazpet.stoc_curent_litri) : 0
  const stocAfter = isGazpet && form.cantitate_litri ? stocCurent - Number(form.cantitate_litri) : null
  
  // Fetch preț mediu ponderat Gazpet (din achiziții vrac)
  useEffect(() => {
    if (!rezervorGazpet?.id) return
    supabase.from('logistica_achizitii_vrac')
      .select('cantitate_litri, pret_per_litru')
      .eq('rezervor_id', rezervorGazpet.id)
      .not('pret_per_litru', 'is', null)
      .then(({ data }) => {
        if (!data?.length) return
        const totalLitri = data.reduce((s, a) => s + Number(a.cantitate_litri || 0), 0)
        const totalCost = data.reduce((s, a) => s + Number(a.cantitate_litri || 0) * Number(a.pret_per_litru || 0), 0)
        if (totalLitri > 0) setPretMediuGazpet((totalCost / totalLitri).toFixed(4))
      })
  }, [rezervorGazpet?.id])
  
  // Pretul de bază folosit la auto-fill (Gazpet → mediu ponderat, altă stație → preț pompă)
  const pretBaza = isGazpet ? (pretMediuGazpet || pretMotorina) : pretMotorina
  
  // Sincronizare bidirecțională cost ↔ preț/litru când se schimbă cantitatea
  useEffect(() => {
    if (!form.cantitate_litri || Number(form.cantitate_litri) <= 0) return
    
    if (lastEdited === 'total' && form.pret_total) {
      // User a editat costul total → recalculez preț/litru
      const ppl = (Number(form.pret_total) / Number(form.cantitate_litri)).toFixed(4)
      setField('pret_per_litru', ppl)
    } else if (lastEdited === 'pret' && form.pret_per_litru) {
      // User a editat preț/litru → recalculez cost total
      const total = (Number(form.pret_per_litru) * Number(form.cantitate_litri)).toFixed(2)
      setField('pret_total', total)
    } else if (!lastEdited && pretBaza) {
      // Prima dată, prefill din preț de bază
      setField('pret_per_litru', Number(pretBaza).toFixed(2))
      setField('pret_total', (Number(form.cantitate_litri) * Number(pretBaza)).toFixed(2))
    }
  }, [form.cantitate_litri])
  
  // Handler pentru cost total (user editează)
  const handleTotalChange = (v) => {
    setField('pret_total', v)
    setLastEdited('total')
    if (v && form.cantitate_litri && Number(form.cantitate_litri) > 0) {
      const ppl = (Number(v) / Number(form.cantitate_litri)).toFixed(4)
      setField('pret_per_litru', ppl)
    } else if (!v) {
      setField('pret_per_litru', '')
    }
  }
  
  // Handler pentru preț/litru (user editează)
  const handlePretLChange = (v) => {
    setField('pret_per_litru', v)
    setLastEdited('pret')
    if (v && form.cantitate_litri && Number(form.cantitate_litri) > 0) {
      const total = (Number(v) * Number(form.cantitate_litri)).toFixed(2)
      setField('pret_total', total)
    } else if (!v) {
      setField('pret_total', '')
    }
  }
  
  // Validare preț/litru — warning pentru valori absurde
  const pretLNum = Number(form.pret_per_litru) || 0
  const isPretSuspect = form.pret_per_litru && (pretLNum < 1 || pretLNum > 20)
  
  const handleSave = async () => {
    if (!form.data_alimentare) { showToast('Selectează data', 'error'); return }
    if (!form.cantitate_litri || Number(form.cantitate_litri) <= 0) { showToast('Cantitatea trebuie > 0', 'error'); return }
    if (isGazpet && stocAfter !== null && stocAfter < 0) {
      const ok = window.confirm(`⚠️ ATENȚIE: Stocul rezervorului Gazpet va deveni NEGATIV (${stocAfter.toFixed(1)} L).\n\nVerifică dacă ai înregistrat toate achizițiile vrac.\n\nContinui oricum?`)
      if (!ok) return
    }
    if (isPretSuspect) {
      const ok = window.confirm(`⚠️ Preț/litru atipic: ${form.pret_per_litru} RON/L\n\nPentru motorină, prețul ar trebui între 6-9 RON/L.\nVerifică valorile introduse!\n\nContinui oricum?`)
      if (!ok) return
    }
    
    setSaving(true)
    const { data: { user } } = await supabase.auth.getUser()
    
    const payload = {
      active_id: activ.id,
      data_alimentare: form.data_alimentare,
      cantitate_litri: Number(form.cantitate_litri),
      ore_la_alimentare: form.ore_la_alimentare ? Number(form.ore_la_alimentare) : null,
      km_la_alimentare: form.km_la_alimentare ? Number(form.km_la_alimentare) : null,
      ore_lucrate_efectiv: form.ore_lucrate_efectiv ? Number(form.ore_lucrate_efectiv) : null,
      statie_combustibil: form.statie_combustibil || null,
      card_combustibil: form.card_combustibil.trim() || null,
      pret_total: form.pret_total ? Number(form.pret_total) : null,
      pret_per_litru: form.pret_per_litru ? Number(form.pret_per_litru) : null,
      numar_factura: form.numar_factura.trim() || null,
      observatii: form.observatii.trim() || null,
      rezervor_id: isGazpet && rezervorGazpet ? rezervorGazpet.id : null,
      site_id: form.site_id ? Number(form.site_id) : null,
      created_by: user?.id,
    }
    
    const { error } = await supabase.from('logistica_alimentari').insert(payload)
    setSaving(false)
    
    if (error) { showToast(`Eroare: ${error.message}`, 'error'); return }
    
    showToast(`✓ Alimentare înregistrată: ${form.cantitate_litri} L${isGazpet ? ' (din Gazpet vrac)' : ''}`, 'success')
    onSaved()
  }
  
  return (
    <div onClick={onClose} style={{position:'fixed', inset:0, background:'#000000cc', zIndex:300, display:'flex', alignItems:'flex-start', justifyContent:'center', padding:'40px 16px', overflowY:'auto'}}>
      <div onClick={e => e.stopPropagation()} style={{...S.card, padding: 22, width: '100%', maxWidth: 620, boxShadow: '0 20px 80px rgba(0,0,0,.6)', borderTop: `3px solid ${G.orange}`}} className="fi">
        
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom: 16, paddingBottom: 14, borderBottom: `1px solid ${G.border}`}}>
          <div>
            <div style={{fontSize: 18, fontWeight: 800, color: G.text, marginBottom: 4}}>
              ⛽ Alimentare combustibil
            </div>
            <div style={{fontSize: 12, color: G.muted}}>
              {activ.marca} {activ.model} {activ.cod_intern && `· ${activ.cod_intern}`}
              {activ.tip_carburant && ` · ${activ.tip_carburant}`}
              {activ.norma_consum && ` · normă ${activ.norma_consum} ${activ.unitate_norma || 'l/h'}`}
            </div>
          </div>
          <button onClick={onClose} style={{background:'transparent', border:'none', color:G.muted, fontSize: 22, cursor:'pointer', padding: 4}}>×</button>
        </div>
        
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12, marginBottom: 12}}>
          <FieldText label="Data alimentării" value={form.data_alimentare} onChange={v => setField('data_alimentare', v)} type="date" required />
          <FieldText label="Cantitate (litri)" value={form.cantitate_litri} onChange={v => setField('cantitate_litri', v)} type="number" placeholder="ex: 50.5" required />
        </div>
        
        <div style={{marginBottom: 4}}>
          <div style={{fontSize: 11, color: G.orange, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.5px', marginBottom: 6}}>
            🏪 Sursa & alocare
          </div>
        </div>
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12, marginBottom: 12}}>
          <FieldSelect label="Stație combustibil" value={form.statie_combustibil} onChange={v => setField('statie_combustibil', v)} options={STATII} placeholder="— alege stația —" />
          <FieldSelect label={isGazpet ? "Șantier (obligatoriu pt. Gazpet)" : "Șantier (opțional)"} value={form.site_id} onChange={v => setField('site_id', v)} options={[{label:'— niciun șantier —', value:''}, ...(sites||[]).map(s => ({label: s.name, value: String(s.id)}))]} placeholder="— niciun șantier —" />
        </div>
        
        {isGazpet && rezervorGazpet && (
          <div style={{padding: 10, marginBottom: 12, background: G.purple + '15', border: `1px solid ${G.purple}55`, borderRadius: 8, fontSize: 12, color: G.text}}>
            <strong style={{color: G.purple}}>📦 Rezervor Gazpet — Oscar</strong>
            <div style={{marginTop: 4, color: G.muted, fontSize: 11, lineHeight: 1.6}}>
              Stoc curent: <strong style={{color: G.text}}>{stocCurent.toFixed(1)} L</strong> din {Number(rezervorGazpet.capacitate_litri).toFixed(0)} L total
              {form.cantitate_litri && stocAfter !== null && (
                <> · <strong style={{color: stocAfter < 0 ? G.red : stocAfter < (Number(rezervorGazpet.capacitate_litri) * Number(rezervorGazpet.prag_alerta_procent) / 100) ? G.orange : G.green}}>
                  După alimentare: {stocAfter.toFixed(1)} L
                </strong></>
              )}
              {pretMediuGazpet && <><br/>Preț mediu ponderat din achiziții vrac: <strong style={{color: G.text}}>{pretMediuGazpet} RON/L</strong></>}
            </div>
          </div>
        )}
        
        <div style={{marginBottom: 4}}>
          <div style={{fontSize: 11, color: G.orange, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.5px', marginBottom: 6}}>
            📊 Citiri pentru analiză consum
          </div>
        </div>
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap: 12, marginBottom: 14}}>
          <FieldText label="Ore bord la alim." value={form.ore_la_alimentare} onChange={v => setField('ore_la_alimentare', v)} type="number" placeholder="ex: 1250" />
          <FieldText label="Km la alimentare" value={form.km_la_alimentare} onChange={v => setField('km_la_alimentare', v)} type="number" placeholder="ex: 145000" />
          <FieldText label="Ore lucrate efectiv" value={form.ore_lucrate_efectiv} onChange={v => setField('ore_lucrate_efectiv', v)} type="number" placeholder="ex: 8" />
        </div>
        
        <div style={{marginBottom: 4}}>
          <div style={{fontSize: 11, color: G.orange, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.5px', marginBottom: 6}}>
            💳 Cost <span style={{fontSize: 10, color: G.muted, fontWeight: 500, textTransform: 'none', letterSpacing: 0}}>
              (auto-fill din {isGazpet && pretMediuGazpet ? `preț mediu Gazpet ${pretMediuGazpet} RON/L` : pretMotorina ? `preț pompă setat ${pretMotorina} RON/L` : 'cantitate × preț'} — editează oricare câmp pentru a recalcula celălalt)
            </span>
          </div>
        </div>
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12, marginBottom: 8}}>
          <FieldText label="Preț per litru (RON/L)" value={form.pret_per_litru} onChange={handlePretLChange} type="number" placeholder="ex: 7.50" />
          <FieldText label="Cost total alimentare (RON)" value={form.pret_total} onChange={handleTotalChange} type="number" placeholder="ex: 380.50" />
        </div>
        
        {/* Warning preț atipic */}
        {isPretSuspect && (
          <div style={{padding: 10, background: G.redDim + '88', border: `1px solid ${G.red}55`, borderRadius: 8, marginBottom: 14, fontSize: 12, color: G.text}}>
            <strong style={{color: G.red}}>⚠️ Preț/litru atipic: {form.pret_per_litru} RON/L</strong>
            <div style={{marginTop: 4, color: G.muted, fontSize: 11, lineHeight: 1.5}}>
              Pentru motorină normală, prețul ar trebui între <strong>6-9 RON/L</strong>. Verifică:
              <br/>· Cantitatea introdusă e corectă? ({form.cantitate_litri} L)
              <br/>· Costul TOTAL e cel din factură, nu prețul per litru?
              <br/>· Calcul corect: <strong>cantitate × preț/L = cost total</strong>
            </div>
          </div>
        )}
        
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12, marginBottom: 14}}>
          <FieldText label="Card combustibil" value={form.card_combustibil} onChange={v => setField('card_combustibil', v)} placeholder="ex: 7059-XXXX-1234" />
          <FieldText label="Număr factură" value={form.numar_factura} onChange={v => setField('numar_factura', v)} placeholder="ex: F-2026-1234" />
        </div>
        
        <div style={{marginBottom: 14}}>
          <FieldTextarea label="Observații" value={form.observatii} onChange={v => setField('observatii', v)} rows={2} />
        </div>
        
        <div style={{display:'flex', justifyContent:'flex-end', gap: 8, paddingTop: 14, borderTop: `1px solid ${G.border}`}}>
          <button onClick={onClose} style={{...S.btnS, fontSize: 13, color: G.muted}} disabled={saving}>Anulează</button>
          <button onClick={handleSave} disabled={saving} style={{...S.btnP, background: G.orange, opacity: saving ? .6 : 1, cursor: saving ? 'wait' : 'pointer'}}>
            {saving ? '⏳ Se salvează...' : '✓ Înregistrează alimentarea'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Modal Achiziție Vrac ────────────────────────────────────────────────────
function AchizitieVracModal({ rezervor, onClose, onSaved, showToast }) {
  const [form, setForm] = useState({
    data_achizitie: new Date().toISOString().split('T')[0],
    cantitate_litri: '',
    furnizor: '',
    numar_factura: '',
    cost_total: '',
    pret_per_litru: '',
    observatii: '',
  })
  const [saving, setSaving] = useState(false)
  const setField = (k, v) => setForm(p => ({ ...p, [k]: v }))
  
  const stocCurent = rezervor?.stoc_curent_litri ? Number(rezervor.stoc_curent_litri) : 0
  const capacitate = rezervor?.capacitate_litri ? Number(rezervor.capacitate_litri) : 0
  const stocAfter = form.cantitate_litri ? stocCurent + Number(form.cantitate_litri) : null
  const overflow = stocAfter !== null && capacitate > 0 && stocAfter > capacitate
  
  useEffect(() => {
    if (form.cost_total && form.cantitate_litri && Number(form.cantitate_litri) > 0) {
      const ppl = (Number(form.cost_total) / Number(form.cantitate_litri)).toFixed(4)
      if (form.pret_per_litru !== ppl) setField('pret_per_litru', ppl)
    }
  }, [form.cost_total, form.cantitate_litri])
  
  const handleSave = async () => {
    if (!form.data_achizitie) { showToast('Selectează data', 'error'); return }
    if (!form.cantitate_litri || Number(form.cantitate_litri) <= 0) { showToast('Cantitatea trebuie > 0', 'error'); return }
    if (overflow) {
      const ok = window.confirm(`⚠️ Cantitatea introdusă va depăși capacitatea rezervorului!\nStoc final: ${stocAfter.toFixed(1)} L · Capacitate: ${capacitate} L\n\nContinui oricum?`)
      if (!ok) return
    }
    
    setSaving(true)
    const { data: { user } } = await supabase.auth.getUser()
    
    const { error } = await supabase.from('logistica_achizitii_vrac').insert({
      rezervor_id: rezervor.id,
      data_achizitie: form.data_achizitie,
      cantitate_litri: Number(form.cantitate_litri),
      furnizor: form.furnizor.trim() || null,
      numar_factura: form.numar_factura.trim() || null,
      cost_total: form.cost_total ? Number(form.cost_total) : null,
      pret_per_litru: form.pret_per_litru ? Number(form.pret_per_litru) : null,
      observatii: form.observatii.trim() || null,
      created_by: user?.id,
    })
    
    setSaving(false)
    if (error) { showToast(`Eroare: ${error.message}`, 'error'); return }
    
    showToast(`✓ Achiziție vrac: +${form.cantitate_litri} L în ${rezervor.nume}`, 'success')
    onSaved()
  }
  
  return (
    <div onClick={onClose} style={{position:'fixed', inset:0, background:'#000000cc', zIndex:300, display:'flex', alignItems:'flex-start', justifyContent:'center', padding:'40px 16px', overflowY:'auto'}}>
      <div onClick={e => e.stopPropagation()} style={{...S.card, padding: 22, width: '100%', maxWidth: 600, boxShadow: '0 20px 80px rgba(0,0,0,.6)', borderTop: `3px solid ${G.purple}`}} className="fi">
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom: 16, paddingBottom: 14, borderBottom: `1px solid ${G.border}`}}>
          <div>
            <div style={{fontSize: 18, fontWeight: 800, color: G.text, marginBottom: 4}}>
              📦 Achiziție vrac în rezervor
            </div>
            <div style={{fontSize: 12, color: G.muted}}>
              {rezervor.nume} · stoc curent: <strong style={{color: G.text}}>{stocCurent.toFixed(1)} L</strong> din {capacitate.toFixed(0)} L
            </div>
          </div>
          <button onClick={onClose} style={{background:'transparent', border:'none', color:G.muted, fontSize: 22, cursor:'pointer', padding: 4}}>×</button>
        </div>
        
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12, marginBottom: 12}}>
          <FieldText label="Data achiziției" value={form.data_achizitie} onChange={v => setField('data_achizitie', v)} type="date" required />
          <FieldText label="Cantitate (litri)" value={form.cantitate_litri} onChange={v => setField('cantitate_litri', v)} type="number" placeholder="ex: 8000" required />
          <FieldText label="Furnizor" value={form.furnizor} onChange={v => setField('furnizor', v)} placeholder="ex: Petrom Distribution" />
          <FieldText label="Număr factură" value={form.numar_factura} onChange={v => setField('numar_factura', v)} placeholder="ex: F-2026-0123" />
          <FieldText label="Cost total (RON)" value={form.cost_total} onChange={v => setField('cost_total', v)} type="number" placeholder="ex: 60000" />
          <FieldText label="Preț/litru (auto)" value={form.pret_per_litru} onChange={v => setField('pret_per_litru', v)} type="number" placeholder="auto-calculat" />
        </div>
        
        <div style={{marginBottom: 14}}>
          <FieldTextarea label="Observații" value={form.observatii} onChange={v => setField('observatii', v)} rows={2} />
        </div>
        
        {form.cantitate_litri && stocAfter !== null && (
          <div style={{padding: 10, background: overflow ? G.redDim : G.greenDim, border: `1px solid ${overflow ? G.red : G.green}33`, borderRadius: 8, marginBottom: 14, fontSize: 12, color: G.text}}>
            <strong style={{color: overflow ? G.red : G.green}}>
              {overflow ? '⚠️ DEPĂȘIRE CAPACITATE!' : '✓ Stoc după achiziție:'}
            </strong>
            <div style={{marginTop: 4, color: G.muted, fontSize: 11}}>
              {stocCurent.toFixed(1)} L + {Number(form.cantitate_litri).toFixed(1)} L = <strong style={{color: G.text}}>{stocAfter.toFixed(1)} L</strong>
              {capacitate > 0 && <> ({(stocAfter / capacitate * 100).toFixed(1)}% din capacitate)</>}
            </div>
          </div>
        )}
        
        <div style={{display:'flex', justifyContent:'flex-end', gap: 8, paddingTop: 14, borderTop: `1px solid ${G.border}`}}>
          <button onClick={onClose} style={{...S.btnS, fontSize: 13, color: G.muted}} disabled={saving}>Anulează</button>
          <button onClick={handleSave} disabled={saving} style={{...S.btnP, background: G.purple, opacity: saving ? .6 : 1, cursor: saving ? 'wait' : 'pointer'}}>
            {saving ? '⏳ Se salvează...' : '✓ Înregistrează achiziția'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Modal Editare Stoc Rezervor (corecții manuale) ──────────────────────────
function EditStocModal({ rezervor, onClose, onSaved, showToast }) {
  const stocCurent = rezervor?.stoc_curent_litri ? Number(rezervor.stoc_curent_litri) : 0
  const cap = rezervor?.capacitate_litri ? Number(rezervor.capacitate_litri) : 0
  const [val, setVal] = useState(String(stocCurent))
  const [motiv, setMotiv] = useState('')
  const [saving, setSaving] = useState(false)
  
  const newStoc = Number(val) || 0
  const diferenta = newStoc - stocCurent
  
  const handleSave = async () => {
    if (val === '' || isNaN(Number(val))) { showToast('Valoare invalidă', 'error'); return }
    if (newStoc < 0) {
      const ok = window.confirm(`⚠️ Stoc NEGATIV: ${newStoc} L. Continui oricum?`)
      if (!ok) return
    }
    if (cap > 0 && newStoc > cap) {
      const ok = window.confirm(`⚠️ Stocul (${newStoc} L) depășește capacitatea rezervorului (${cap} L). Continui oricum?`)
      if (!ok) return
    }
    
    setSaving(true)
    const { error } = await supabase.from('logistica_rezervoare')
      .update({ 
        stoc_curent_litri: newStoc,
        observatii: motiv.trim() ? `[${new Date().toISOString().split('T')[0]}] Ajustare manuală: ${stocCurent} → ${newStoc} L. Motiv: ${motiv.trim()}\n${rezervor.observatii || ''}`.trim() : rezervor.observatii
      })
      .eq('id', rezervor.id)
    setSaving(false)
    
    if (error) { showToast(`Eroare: ${error.message}`, 'error'); return }
    
    showToast(`✓ Stoc ajustat: ${stocCurent.toFixed(1)} → ${newStoc.toFixed(1)} L (${diferenta > 0 ? '+' : ''}${diferenta.toFixed(1)})`, 'success')
    onSaved()
  }
  
  return (
    <div onClick={onClose} style={{position:'fixed', inset:0, background:'#000000cc', zIndex:300, display:'flex', alignItems:'center', justifyContent:'center', padding:'40px 16px'}}>
      <div onClick={e => e.stopPropagation()} style={{...S.card, padding: 22, width: '100%', maxWidth: 500, boxShadow: '0 20px 80px rgba(0,0,0,.6)', borderTop: `3px solid ${G.yellow}`}} className="fi">
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom: 16, paddingBottom: 12, borderBottom: `1px solid ${G.border}`}}>
          <div>
            <div style={{fontSize: 18, fontWeight: 800, color: G.text, marginBottom: 4}}>
              ✏️ Ajustare stoc rezervor
            </div>
            <div style={{fontSize: 12, color: G.muted}}>
              {rezervor.nume} · capacitate: {cap.toFixed(0)} L
            </div>
          </div>
          <button onClick={onClose} style={{background:'transparent', border:'none', color:G.muted, fontSize: 22, cursor:'pointer', padding: 4}}>×</button>
        </div>
        
        <div style={{marginBottom: 12, padding: 12, background: G.bg, borderRadius: 8}}>
          <div style={{fontSize: 11, color: G.muted, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.4px', marginBottom: 4}}>
            Stoc curent înregistrat
          </div>
          <div style={{fontSize: 22, fontWeight: 800, color: G.text, fontVariantNumeric: 'tabular-nums'}}>
            {stocCurent.toFixed(2)} <span style={{fontSize: 12, color: G.muted}}>L</span>
          </div>
        </div>
        
        <FieldText label="Stoc nou (L)" value={val} onChange={v => setVal(v)} type="number" placeholder="ex: 0 sau 8500.5" />
        
        <div style={{display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap'}}>
          <button onClick={() => setVal('0')} style={{...S.btnS, fontSize: 11, padding: '5px 10px', color: G.red, borderColor: G.red + '55'}}>
            ⟲ Reset la 0
          </button>
          {cap > 0 && (
            <button onClick={() => setVal(String(cap))} style={{...S.btnS, fontSize: 11, padding: '5px 10px', color: G.green, borderColor: G.green + '55'}}>
              ⤴ Plin ({cap} L)
            </button>
          )}
          <button onClick={() => setVal(String(stocCurent))} style={{...S.btnS, fontSize: 11, padding: '5px 10px', color: G.muted}}>
            ↺ Înapoi la curent
          </button>
        </div>
        
        {val !== '' && !isNaN(Number(val)) && diferenta !== 0 && (
          <div style={{marginTop: 12, padding: 10, background: diferenta > 0 ? G.greenDim : G.redDim, border: `1px solid ${diferenta > 0 ? G.green : G.red}33`, borderRadius: 8, fontSize: 12, color: G.text}}>
            <strong style={{color: diferenta > 0 ? G.green : G.red}}>
              Modificare: {diferenta > 0 ? '+' : ''}{diferenta.toFixed(2)} L
            </strong>
            <div style={{marginTop: 4, color: G.muted, fontSize: 11}}>
              {stocCurent.toFixed(1)} L → <strong style={{color: G.text}}>{newStoc.toFixed(1)} L</strong>
            </div>
          </div>
        )}
        
        <div style={{marginTop: 14}}>
          <FieldTextarea label="Motiv ajustare (opțional, pentru audit)" value={motiv} onChange={setMotiv} rows={2} />
        </div>
        
        <div style={{padding: 8, background: G.yellowDim + '88', border: `1px solid ${G.yellow}33`, borderRadius: 8, marginTop: 12, fontSize: 11, color: G.muted, lineHeight: 1.5}}>
          ⚠️ Această ajustare modifică direct stocul, fără să fie înregistrată ca achiziție sau alimentare. Folosește doar pentru corecții (inventar, erori). Motivul se salvează în observații pentru audit.
        </div>
        
        <div style={{display:'flex', justifyContent:'flex-end', gap: 8, marginTop: 18, paddingTop: 12, borderTop: `1px solid ${G.border}`}}>
          <button onClick={onClose} style={{...S.btnS, fontSize: 13, color: G.muted}} disabled={saving}>Anulează</button>
          <button onClick={handleSave} disabled={saving || diferenta === 0} style={{...S.btnP, background: G.yellow, color: '#000', opacity: (saving || diferenta === 0) ? .5 : 1}}>
            {saving ? '⏳' : '✓ Salvează ajustarea'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Modal setări preț motorină ──────────────────────────────────────────────
function SetariMotorinaModal({ pret, dataActualizat, onClose, onSaved, showToast }) {
  const [val, setVal] = useState(pret || '7.50')
  const [saving, setSaving] = useState(false)
  
  const handleSave = async () => {
    if (!val || isNaN(Number(val)) || Number(val) <= 0) { showToast('Preț invalid', 'error'); return }
    setSaving(true)
    const { data: { user } } = await supabase.auth.getUser()
    const today = new Date().toISOString().split('T')[0]
    await supabase.from('logistica_setari').upsert([
      { key: 'pret_motorina_ron', value: String(val), updated_at: new Date().toISOString(), updated_by: user?.id },
      { key: 'pret_motorina_actualizat', value: today, updated_at: new Date().toISOString(), updated_by: user?.id },
    ])
    setSaving(false)
    showToast(`✓ Preț actualizat: ${val} RON/L`, 'success')
    onSaved()
  }
  
  return (
    <div onClick={onClose} style={{position:'fixed', inset:0, background:'#000000cc', zIndex:300, display:'flex', alignItems:'center', justifyContent:'center', padding:'40px 16px'}}>
      <div onClick={e => e.stopPropagation()} style={{...S.card, padding: 22, width: '100%', maxWidth: 460, boxShadow: '0 20px 80px rgba(0,0,0,.6)'}} className="fi">
        <div style={{fontSize: 17, fontWeight: 800, color: G.text, marginBottom: 4}}>💰 Preț motorină</div>
        <div style={{fontSize: 11, color: G.muted, marginBottom: 16}}>
          Folosit la auto-fill cost în formularul de alimentare. Ultima actualizare: {dataActualizat || '—'}
        </div>
        <FieldText label="Preț motorină (RON/L)" value={val} onChange={v => setVal(v)} type="number" placeholder="ex: 7.50" />
        <div style={{padding: 10, background: G.bg, borderRadius: 8, marginTop: 14, fontSize: 11, color: G.muted, lineHeight: 1.6}}>
          💡 În viitor: auto-update zilnic de pe sites publice (ANRE, Petrom, OMV). Pentru moment, actualizare manuală.
        </div>
        <div style={{display:'flex', justifyContent:'flex-end', gap: 8, marginTop: 18, paddingTop: 12, borderTop: `1px solid ${G.border}`}}>
          <button onClick={onClose} style={{...S.btnS, fontSize: 13, color: G.muted}}>Anulează</button>
          <button onClick={handleSave} disabled={saving} style={S.btnP}>{saving ? '⏳' : '✓ Salvează'}</button>
        </div>
      </div>
    </div>
  )
}

// ─── Modal Mentenanță Făcută ─────────────────────────────────────────────────

// ─── Modal Mentenanță Făcută ─────────────────────────────────────────────────
function MentenantaFacutaModal({ activ, plan, onClose, onSaved, showToast }) {
  const [form, setForm] = useState({
    data_revizie: new Date().toISOString().split('T')[0],
    data_expirare: '',
    numar_document: '',
    ore_la_revizie: plan?.urmatoarea_ore || '',
    km_la_revizie: plan?.urmatoarea_km || '',
    tip_revizie: 'revizie',
    cost: '',
    service_furnizor: '',
    observatii: '',
  })
  const [saving, setSaving] = useState(false)
  const setField = (k, v) => setForm(p => ({ ...p, [k]: v }))
  
  // Tip e DOCUMENT (ITP/RCA/CASCO) sau MECANIC (revizie/reparatie)
  const isDocument = ['ITP', 'RCA', 'CASCO'].includes(form.tip_revizie)
  const isMecanic = ['revizie', 'reparatie'].includes(form.tip_revizie)
  
  // Calculez auto data expirare default pentru documente
  useEffect(() => {
    if (isDocument && form.data_revizie && !form.data_expirare) {
      // ITP = 1 an pentru auto noi/2 ani vechi, RCA/CASCO = 1 an default
      const luniValabilitate = form.tip_revizie === 'ITP' ? 12 : 12
      const d = new Date(form.data_revizie)
      d.setMonth(d.getMonth() + luniValabilitate)
      setField('data_expirare', d.toISOString().split('T')[0])
    }
  }, [form.tip_revizie, form.data_revizie])
  
  // Reset câmpuri irelevante la schimbarea tipului
  useEffect(() => {
    if (isDocument) {
      setField('ore_la_revizie', '')
      setField('km_la_revizie', '')
    }
    if (isMecanic) {
      setField('data_expirare', '')
      setField('numar_document', '')
    }
  }, [form.tip_revizie])
  
  // Label-uri dinamice
  const labels = {
    revizie:    { titlu: '✅ Revizie efectuată',         data: 'Data efectuării',  service: 'Service / Furnizor',   placeholder: 'ex: Service Auto Ploiești' },
    reparatie:  { titlu: '🔧 Reparație efectuată',       data: 'Data efectuării',  service: 'Service / Furnizor',   placeholder: 'ex: Service Auto Ploiești' },
    ITP:        { titlu: '📋 ITP înregistrat',           data: 'Data emiterii',    service: 'Stație ITP',           placeholder: 'ex: ITP Ploiești - Pop Auto' },
    RCA:        { titlu: '🛡️ Asigurare RCA',             data: 'Data emiterii',    service: 'Asigurător',           placeholder: 'ex: Allianz Țiriac, Groupama, Omniasig' },
    CASCO:      { titlu: '🛡️ Asigurare CASCO',           data: 'Data emiterii',    service: 'Asigurător',           placeholder: 'ex: Allianz Țiriac, Groupama, Omniasig' },
    altele:     { titlu: '📝 Înregistrare',              data: 'Data',             service: 'Furnizor / Prestator', placeholder: '' },
  }
  const L = labels[form.tip_revizie] || labels.altele
  
  const handleSave = async () => {
    if (!form.data_revizie) { showToast('Selectează data', 'error'); return }
    if (isDocument && !form.data_expirare) { showToast('Pentru documente trebuie data expirării', 'error'); return }
    
    setSaving(true)
    const { data: { user } } = await supabase.auth.getUser()
    
    // 1. INSERT în istoric
    const istoricPayload = {
      active_id: activ.id,
      data_revizie: form.data_revizie,
      data_expirare: form.data_expirare || null,
      numar_document: form.numar_document.trim() || null,
      ore_la_revizie: form.ore_la_revizie ? Number(form.ore_la_revizie) : null,
      km_la_revizie: form.km_la_revizie ? Number(form.km_la_revizie) : null,
      tip_revizie: form.tip_revizie,
      cost: form.cost ? Number(form.cost) : null,
      service_furnizor: form.service_furnizor.trim() || null,
      observatii: form.observatii.trim() || null,
      created_by: user?.id,
    }
    
    const { error: insErr } = await supabase
      .from('logistica_mentenanta_istoric')
      .insert(istoricPayload)
    
    if (insErr) {
      setSaving(false)
      showToast(`Eroare: ${insErr.message}`, 'error')
      return
    }
    
    // 2. UPDATE plan DOAR pentru revizie/reparație (nu pentru documente)
    if (isMecanic) {
      const updateFields = {
        ultima_revizie_data: form.data_revizie,
        ultima_revizie_ore: form.ore_la_revizie ? Number(form.ore_la_revizie) : null,
        ultima_revizie_km: form.km_la_revizie ? Number(form.km_la_revizie) : null,
        updated_by: user?.id,
      }
      const intervalOre = plan?.interval_ore || null
      const intervalKm = plan?.interval_km || null
      if (intervalOre && form.ore_la_revizie) {
        updateFields.urmatoarea_ore = Number(form.ore_la_revizie) + intervalOre
      }
      if (intervalKm && form.km_la_revizie) {
        updateFields.urmatoarea_km = Number(form.km_la_revizie) + intervalKm
      }
      const newDate = new Date(form.data_revizie)
      if (intervalOre && form.ore_la_revizie) {
        const daysEstimate = Math.round(intervalOre / 8)
        newDate.setDate(newDate.getDate() + Math.min(daysEstimate, 365))
      } else {
        newDate.setDate(newDate.getDate() + 365)
      }
      updateFields.urmatoarea_data = newDate.toISOString().split('T')[0]
      
      let upErr
      if (plan?.id) {
        const r = await supabase.from('logistica_mentenanta_plan').update(updateFields).eq('id', plan.id)
        upErr = r.error
      } else {
        const r = await supabase.from('logistica_mentenanta_plan').insert({ active_id: activ.id, ...updateFields })
        upErr = r.error
      }
      if (upErr) {
        setSaving(false)
        showToast(`Înregistrat, dar eroare la actualizare plan: ${upErr.message}`, 'warn')
        onSaved()
        return
      }
    }
    
    setSaving(false)
    const successMsg = isDocument 
      ? `✓ ${form.tip_revizie} înregistrat (valabil până la ${new Date(form.data_expirare).toLocaleDateString('ro-RO')})`
      : '✓ Mentenanță înregistrată cu succes!'
    showToast(successMsg, 'success')
    onSaved()
  }
  
  return (
    <div onClick={onClose} style={{position:'fixed', inset:0, background:'#000000cc', zIndex:300, display:'flex', alignItems:'flex-start', justifyContent:'center', padding:'40px 16px', overflowY:'auto'}}>
      <div onClick={e => e.stopPropagation()} style={{...S.card, padding: 22, width: '100%', maxWidth: 600, boxShadow: '0 20px 80px rgba(0,0,0,.6)', borderTop: `3px solid ${isDocument ? G.blue : G.green}`}} className="fi">
        
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom: 16, paddingBottom: 14, borderBottom: `1px solid ${G.border}`}}>
          <div>
            <div style={{fontSize: 18, fontWeight: 800, color: G.text, marginBottom: 4}}>
              {L.titlu}
            </div>
            <div style={{fontSize: 12, color: G.muted}}>
              {activ.marca} {activ.model} {activ.cod_intern && `· ${activ.cod_intern}`}
            </div>
          </div>
          <button onClick={onClose} style={{background:'transparent', border:'none', color:G.muted, fontSize: 22, cursor:'pointer', padding: 4}}>×</button>
        </div>
        
        {/* Tip — întotdeauna primul */}
        <div style={{marginBottom: 12}}>
          <FieldSelect label="Tip" value={form.tip_revizie} onChange={v => setField('tip_revizie', v)} options={['revizie', 'reparatie', 'ITP', 'RCA', 'CASCO', 'altele']} required />
        </div>
        
        {/* Câmpuri DINAMICE pe baza tipului */}
        {isMecanic && (
          <>
            <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12, marginBottom: 12}}>
              <FieldText label={L.data} value={form.data_revizie} onChange={v => setField('data_revizie', v)} type="date" required />
              <FieldText label={L.service} value={form.service_furnizor} onChange={v => setField('service_furnizor', v)} placeholder={L.placeholder} />
              <FieldText label="Ore funcționare la revizie" value={form.ore_la_revizie} onChange={v => setField('ore_la_revizie', v)} type="number" placeholder="ex: 1250" />
              <FieldText label="Kilometri la revizie" value={form.km_la_revizie} onChange={v => setField('km_la_revizie', v)} type="number" placeholder="ex: 145000" />
              <FieldText label="Cost (RON)" value={form.cost} onChange={v => setField('cost', v)} type="number" placeholder="ex: 1250.50" />
              <div></div>
            </div>
          </>
        )}
        
        {isDocument && (
          <>
            <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12, marginBottom: 12}}>
              <FieldText label={L.data} value={form.data_revizie} onChange={v => setField('data_revizie', v)} type="date" required />
              <FieldText label={`📅 Data expirării ${form.tip_revizie}`} value={form.data_expirare} onChange={v => setField('data_expirare', v)} type="date" required />
              <FieldText label={L.service} value={form.service_furnizor} onChange={v => setField('service_furnizor', v)} placeholder={L.placeholder} />
              <FieldText label={`Număr ${form.tip_revizie === 'ITP' ? 'proces verbal' : 'poliță'}`} value={form.numar_document} onChange={v => setField('numar_document', v)} placeholder={form.tip_revizie === 'ITP' ? 'ex: PV-2026-1234' : 'ex: AGG-12345678'} />
              <FieldText label="Cost (RON)" value={form.cost} onChange={v => setField('cost', v)} type="number" placeholder="ex: 850" />
              <div></div>
            </div>
          </>
        )}
        
        {form.tip_revizie === 'altele' && (
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12, marginBottom: 12}}>
            <FieldText label={L.data} value={form.data_revizie} onChange={v => setField('data_revizie', v)} type="date" required />
            <FieldText label="Data expirare (opțional)" value={form.data_expirare} onChange={v => setField('data_expirare', v)} type="date" />
            <FieldText label={L.service} value={form.service_furnizor} onChange={v => setField('service_furnizor', v)} placeholder={L.placeholder} />
            <FieldText label="Cost (RON)" value={form.cost} onChange={v => setField('cost', v)} type="number" placeholder="ex: 250" />
          </div>
        )}
        
        <div style={{marginBottom: 14}}>
          <FieldTextarea label="Observații" value={form.observatii} onChange={v => setField('observatii', v)} rows={2} />
        </div>
        
        {/* Preview pentru REVIZIE: următoarea calculată */}
        {isMecanic && (plan?.interval_ore || plan?.interval_km) && (form.ore_la_revizie || form.km_la_revizie) && (
          <div style={{padding: 10, background: G.greenDim, border: `1px solid ${G.green}33`, borderRadius: 8, marginBottom: 14, fontSize: 12, color: G.text}}>
            <strong style={{color: G.green}}>📅 Următoarea revizie va fi calculată:</strong>
            <div style={{marginTop: 4, color: G.muted}}>
              {plan?.interval_ore && form.ore_la_revizie && <>· la {Number(form.ore_la_revizie) + plan.interval_ore} ore funcționare<br/></>}
              {plan?.interval_km && form.km_la_revizie && <>· la {(Number(form.km_la_revizie) + plan.interval_km).toLocaleString('ro-RO')} km<br/></>}
              · sau aproximativ în 1 an de la data introdusă
            </div>
          </div>
        )}
        
        {/* Preview pentru DOCUMENTE: avertizare scadență */}
        {isDocument && form.data_expirare && (() => {
          const days = daysUntil(form.data_expirare)
          const color = days < 30 ? G.red : days < 90 ? G.orange : G.green
          const bg = days < 30 ? G.redDim : days < 90 ? G.yellowDim : G.greenDim
          return (
            <div style={{padding: 10, background: bg, border: `1px solid ${color}33`, borderRadius: 8, marginBottom: 14, fontSize: 12, color: G.text}}>
              <strong style={{color}}>📅 Documentul va fi valabil până pe {new Date(form.data_expirare).toLocaleDateString('ro-RO')}</strong>
              <div style={{marginTop: 4, color: G.muted}}>
                {days > 0 ? `· ${days} zile de la data introdusă` : `· EXPIRAT! cu ${Math.abs(days)} zile`}
              </div>
            </div>
          )
        })()}
        
        <div style={{display:'flex', justifyContent:'flex-end', gap: 8, paddingTop: 14, borderTop: `1px solid ${G.border}`}}>
          <button onClick={onClose} style={{...S.btnS, fontSize: 13, color: G.muted}} disabled={saving}>Anulează</button>
          <button onClick={handleSave} disabled={saving} style={{...S.btnP, background: isDocument ? G.blue : G.green, opacity: saving ? .6 : 1, cursor: saving ? 'wait' : 'pointer'}}>
            {saving ? '⏳ Se salvează...' : (isDocument ? `✓ Înregistrează ${form.tip_revizie}` : '✓ Înregistrează mentenanța')}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Modal Form (View / Edit / Create) ───────────────────────────────────────
function ActivFormModal({ activ, initialMode, categorii, onClose, onSaved, accessLevel, showToast, rezervorGazpet, sites, pretMotorina }) {
  const [mode, setMode] = useState(initialMode)
  const [saving, setSaving] = useState(false)
  
  const fromActiv = (a) => ({
    cod_intern: a?.cod_intern || '',
    nr_inventar: a?.nr_inventar || '',
    nr_inmatriculare: a?.nr_inmatriculare || '',
    tip: a?.logistica_categorii?.tip || '',
    subcategorie: a?.logistica_categorii?.subcategorie || '',
    marca: a?.marca || '',
    model: a?.model || '',
    an_fabricatie: a?.an_fabricatie || '',
    stare: a?.stare || 'Functional',
    firma_proprietara: a?.firma_proprietara || 'Gazpet Instal',
    tip_carburant: a?.tip_carburant || '',
    norma_consum: a?.norma_consum || '',
    unitate_norma: a?.unitate_norma || 'l/h',
    prag_alerta_consum: a?.prag_alerta_consum || '10',
    link_fisa_nas: a?.link_fisa_nas || '',
    observatii: a?.observatii || '',
    serie_sasiu: a?.serie_sasiu || '',
  })
  
  const [form, setForm] = useState(fromActiv(activ))
  const setField = (k, v) => setForm(p => ({ ...p, [k]: v }))
  const [showMent, setShowMent] = useState(false)
  const [showAlim, setShowAlim] = useState(false)
  const [istoric, setIstoric] = useState([])
  const [alimentari, setAlimentari] = useState([])
  
  // Fetch istoric + alimentări când se deschide în view
  useEffect(() => {
    if (mode === 'view' && activ?.id) {
      supabase.from('logistica_mentenanta_istoric')
        .select('*')
        .eq('active_id', activ.id)
        .order('data_revizie', { ascending: false })
        .then(({ data }) => setIstoric(data || []))
      supabase.from('logistica_alimentari')
        .select('*')
        .eq('active_id', activ.id)
        .order('data_alimentare', { ascending: false })
        .then(({ data }) => setAlimentari(data || []))
    }
  }, [mode, activ?.id])
  
  const tipuri = useMemo(() => ['', ...Array.from(new Set(categorii.map(c => c.tip))).sort()], [categorii])
  const subcategoriiDisponibile = useMemo(() => {
    const subs = categorii.filter(c => c.tip === form.tip && c.subcategorie).map(c => c.subcategorie).sort()
    return ['', ...subs]
  }, [form.tip, categorii])
  
  // Reset subcategorie când se schimbă tipul
  useEffect(() => {
    if (form.tip && form.subcategorie && !subcategoriiDisponibile.includes(form.subcategorie)) {
      setField('subcategorie', '')
    }
  }, [form.tip])
  
  const isReadOnly = mode === 'view'
  const canEdit = accessLevel === 'admin' || accessLevel === 'editor'
  const mentenanta = activ?.logistica_mentenanta_plan?.[0]
  const days = mentenanta?.urmatoarea_data ? daysUntil(mentenanta.urmatoarea_data) : null
  
  const handleSave = async () => {
    if (!form.tip) { showToast('Selectează tipul (Camion, Utilaj, Autoturism...)', 'error'); return }
    if (!form.model.trim()) { showToast('Modelul este obligatoriu', 'error'); return }
    if (!form.cod_intern.trim() && !form.nr_inmatriculare.trim()) {
      showToast('Trebuie cod intern SAU plăcuță înmatriculare', 'error'); return
    }
    if (form.an_fabricatie && (Number(form.an_fabricatie) < 1900 || Number(form.an_fabricatie) > 2030)) {
      showToast('An invalid (1900-2030)', 'error'); return
    }
    
    const cat = categorii.find(c => 
      c.tip === form.tip && 
      ((c.subcategorie || null) === (form.subcategorie || null))
    )
    if (!cat) {
      showToast(`Categoria "${form.tip}${form.subcategorie ? ' / '+form.subcategorie : ''}" nu există`, 'error'); return
    }
    
    setSaving(true)
    
    const payload = {
      cod_intern: form.cod_intern.trim() || null,
      nr_inventar: form.nr_inventar.trim() || null,
      nr_inmatriculare: form.nr_inmatriculare.trim() || null,
      categorie_id: cat.id,
      marca: form.marca.trim() || null,
      model: form.model.trim(),
      an_fabricatie: form.an_fabricatie ? Number(form.an_fabricatie) : null,
      stare: form.stare,
      firma_proprietara: form.firma_proprietara || null,
      tip_carburant: form.tip_carburant || null,
      norma_consum: form.norma_consum ? Number(form.norma_consum) : null,
      unitate_norma: form.unitate_norma || null,
      prag_alerta_consum: form.prag_alerta_consum ? Number(form.prag_alerta_consum) : 10,
      link_fisa_nas: form.link_fisa_nas.trim() || null,
      observatii: form.observatii.trim() || null,
      serie_sasiu: form.serie_sasiu.trim() || null,
    }
    
    let result
    if (mode === 'create') {
      const { data: { user } } = await supabase.auth.getUser()
      result = await supabase.from('logistica_active')
        .insert({ ...payload, created_by: user?.id })
        .select('*, logistica_categorii(tip, subcategorie), logistica_mentenanta_plan(urmatoarea_data, urmatoarea_ore)')
        .single()
    } else {
      result = await supabase.from('logistica_active')
        .update(payload).eq('id', activ.id)
        .select('*, logistica_categorii(tip, subcategorie), logistica_mentenanta_plan(urmatoarea_data, urmatoarea_ore)')
        .single()
    }
    
    setSaving(false)
    if (result.error) {
      let msg = result.error.message
      if (msg.includes('duplicate key')) {
        if (msg.includes('cod_intern')) msg = `Codul intern "${form.cod_intern}" există deja!`
        else if (msg.includes('nr_inmatriculare')) msg = `Plăcuța "${form.nr_inmatriculare}" există deja!`
      }
      showToast(`Eroare: ${msg}`, 'error')
      return
    }
    
    showToast(mode === 'create' ? '✓ Activ creat cu succes!' : '✓ Modificările salvate', 'success')
    onSaved(result.data)
  }
  
  const handleDelete = async () => {
    const label = `${activ.marca || ''} ${activ.model || ''}`.trim() || activ.cod_intern || activ.nr_inmatriculare || `ID ${activ.id}`
    const confirmed = window.confirm(
      `⚠️ ATENȚIE — Ștergere ireversibilă\n\n` +
      `Sigur vrei să ștergi:\n"${label}"?\n\n` +
      `Vor fi șterse și:\n` +
      `· planul de mentenanță asociat\n` +
      `· toate alocările istorice\n` +
      `· documentele atașate\n\n` +
      `Această acțiune NU poate fi anulată.`
    )
    if (!confirmed) return
    
    setSaving(true)
    const { error } = await supabase.from('logistica_active').delete().eq('id', activ.id)
    setSaving(false)
    
    if (error) {
      showToast(`Eroare la ștergere: ${error.message}`, 'error')
      return
    }
    
    showToast(`✓ Șters: ${label}`, 'success')
    onSaved()
  }
  
  const titleMain = mode === 'create' 
    ? '+ Activ nou'
    : `${activ?.marca || '—'} ${activ?.model || ''}`.trim()
  const titleSub = mode === 'edit' ? '✏️ Editare' : mode === 'create' ? 'Completează detaliile' : null
  
  return (
    <div onClick={mode === 'view' ? onClose : undefined} style={{
      position:'fixed', inset:0, background:'#000000aa', zIndex:200,
      display:'flex', alignItems:'flex-start', justifyContent:'center',
      padding:'30px 16px', overflowY:'auto'
    }}>
      <div onClick={e => e.stopPropagation()} style={{...S.card, padding: 22, width: '100%', maxWidth: 760, boxShadow: '0 20px 80px rgba(0,0,0,.6)'}} className="fi">
        
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom: 16, gap: 12, paddingBottom: 14, borderBottom: `1px solid ${G.border}`}}>
          <div style={{flex: 1}}>
            <div style={{fontSize: 19, fontWeight: 800, color: G.text, marginBottom: 4}}>{titleMain}</div>
            {titleSub ? (
              <div style={{fontSize: 12, color: G.logistica, fontWeight: 600}}>{titleSub}</div>
            ) : (
              <div style={{display:'flex', gap: 8, alignItems:'center', flexWrap:'wrap', marginTop: 4}}>
                {activ?.cod_intern && <span style={{background: G.blue+'22', color: G.blue, fontSize: 11, fontWeight: 700, padding: '3px 10px', borderRadius: 12}}>{activ.cod_intern}</span>}
                {activ?.nr_inmatriculare && <span style={{background: G.purple+'22', color: G.purple, fontSize: 11, fontWeight: 700, padding: '3px 10px', borderRadius: 12}}>🚗 {activ.nr_inmatriculare}</span>}
                <StareBadge stare={activ?.stare} />
              </div>
            )}
          </div>
          <div style={{display:'flex', gap: 6, flexWrap: 'wrap'}}>
            {mode === 'view' && canEdit && (
              <>
                <button onClick={() => setShowAlim(true)} style={{...S.btnS, fontSize: 12, color: G.orange, borderColor: G.orange + '55'}}>
                  ⛽ Alimentare
                </button>
                <button onClick={() => setShowMent(true)} style={{...S.btnS, fontSize: 12, color: G.green, borderColor: G.green + '55'}}>
                  ✅ Mentenanță
                </button>
                <button onClick={() => setMode('edit')} style={{...S.btnS, fontSize: 12, color: G.logistica, borderColor: G.logistica + '55'}}>
                  ✏️ Editează
                </button>
                {accessLevel === 'admin' && (
                  <button onClick={handleDelete} disabled={saving} style={{
                    ...S.btnS, fontSize: 12, color: G.red, borderColor: G.red + '55',
                    opacity: saving ? .5 : 1
                  }}>
                    🗑️ Șterge
                  </button>
                )}
              </>
            )}
            <button onClick={onClose} style={{background:'transparent', border:'none', color:G.muted, fontSize: 22, cursor:'pointer', padding: 4, lineHeight: 1}}>×</button>
          </div>
        </div>
        
        {mode === 'view' && (mentenanta?.urmatoarea_data || mentenanta?.urmatoarea_ore) && (
          <div style={{
            marginBottom: 14, padding: 12,
            background: days !== null && days < 0 ? G.redDim : days !== null && days <= 30 ? G.yellowDim : G.greenDim,
            border: `1px solid ${days !== null && days < 0 ? G.red : days !== null && days <= 30 ? G.yellow : G.green}33`,
            borderRadius: 10
          }}>
            <div style={{fontSize: 11, color: G.muted, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.4px', marginBottom: 4}}>🔧 Plan Mentenanță</div>
            <div style={{fontSize: 13, color: G.text, fontWeight: 600}}>
              {mentenanta.urmatoarea_data && <>Următoarea revizie: <strong>{fmtDate(mentenanta.urmatoarea_data)}</strong>
                {days !== null && <span style={{marginLeft: 8, fontSize: 12, color: days < 0 ? G.red : days <= 30 ? G.orange : G.green}}>
                  ({days < 0 ? `întârziere ${Math.abs(days)} zile` : days === 0 ? 'astăzi' : `în ${days} zile`})
                </span>}
              </>}
              {mentenanta.urmatoarea_ore && <div style={{marginTop: 4, fontSize: 12}}>Ore funcționare prag: <strong>{mentenanta.urmatoarea_ore.toLocaleString('ro-RO')}</strong></div>}
            </div>
          </div>
        )}
        
        <div style={{marginBottom: 14}}>
          <div style={{fontSize: 11, color: G.logistica, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.6px', marginBottom: 8}}>🆔 Identificare</div>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12}}>
            <FieldText label="Cod intern (TST...)" value={form.cod_intern} onChange={v => setField('cod_intern', v)} placeholder="ex: TST094" readonly={isReadOnly} />
            <FieldText label="Nr inventar" value={form.nr_inventar} onChange={v => setField('nr_inventar', v)} placeholder="ex: MF-00123" readonly={isReadOnly} />
            <FieldText label="Plăcuță înmatriculare" value={form.nr_inmatriculare} onChange={v => setField('nr_inmatriculare', v)} placeholder="ex: PH 99 GAZ" readonly={isReadOnly} />
            <FieldSelect label="Tip" value={form.tip} onChange={v => setField('tip', v)} options={tipuri} required={!isReadOnly} placeholder="— alege tipul —" readonly={isReadOnly} />
            <FieldSelect label="Subcategorie" value={form.subcategorie} onChange={v => setField('subcategorie', v)} options={subcategoriiDisponibile} placeholder={subcategoriiDisponibile.length > 1 ? '— alege subcategorie —' : '— niciuna —'} readonly={isReadOnly} />
            <FieldText label="Marcă" value={form.marca} onChange={v => setField('marca', v)} placeholder="ex: CATERPILLAR" readonly={isReadOnly} />
            <FieldText label="Model" value={form.model} onChange={v => setField('model', v)} placeholder="ex: D6N XL" required={!isReadOnly} readonly={isReadOnly} />
            <FieldText label="An fabricație" value={form.an_fabricatie} onChange={v => setField('an_fabricatie', v)} type="number" placeholder="ex: 2018" readonly={isReadOnly} />
            <FieldSelect label="Stare" value={form.stare} onChange={v => setField('stare', v)} options={STARI} readonly={isReadOnly} />
          </div>
        </div>
        
        <div style={{marginBottom: 14}}>
          <div style={{fontSize: 11, color: G.logistica, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.6px', marginBottom: 8}}>⚙️ Tehnice</div>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap: 12}}>
            <FieldSelect label="Tip carburant" value={form.tip_carburant} onChange={v => setField('tip_carburant', v)} options={TIPURI_CARBURANT} placeholder="— niciunul —" readonly={isReadOnly} />
            <FieldText label="Normă consum" value={form.norma_consum} onChange={v => setField('norma_consum', v)} type="number" placeholder="ex: 12.5" readonly={isReadOnly} />
            <FieldSelect label="Unitate" value={form.unitate_norma} onChange={v => setField('unitate_norma', v)} options={UNITATI_NORMA} readonly={isReadOnly} />
            <FieldText label="Prag alertă consum (%)" value={form.prag_alerta_consum} onChange={v => setField('prag_alerta_consum', v)} type="number" placeholder="10" readonly={isReadOnly} />
            <FieldText label="Serie șasiu (VIN)" value={form.serie_sasiu} onChange={v => setField('serie_sasiu', v)} placeholder="ex: WDB9061..." readonly={isReadOnly} />
            <FieldSelect label="Firmă proprietară" value={form.firma_proprietara} onChange={v => setField('firma_proprietara', v)} options={FIRME} readonly={isReadOnly} />
          </div>
        </div>
        
        <div style={{marginBottom: 14}}>
          <div style={{fontSize: 11, color: G.logistica, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.6px', marginBottom: 8}}>📎 Documente</div>
          <div style={{display:'flex', flexDirection: 'column', gap: 12}}>
            <FieldTextarea label="Link fișă service NAS" value={form.link_fisa_nas} onChange={v => setField('link_fisa_nas', v)} rows={2} mono readonly={isReadOnly} />
            <FieldTextarea label="Observații" value={form.observatii} onChange={v => setField('observatii', v)} rows={2} readonly={isReadOnly} />
          </div>
        </div>
        
        {/* Istoric mentenanță (doar în view) */}
        {mode === 'view' && istoric.length > 0 && (
          <div style={{marginBottom: 14}}>
            <div style={{fontSize: 11, color: G.logistica, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.6px', marginBottom: 8}}>
              📜 Istoric mentenanță ({istoric.length})
            </div>
            <div style={{...S.card, padding: 0, overflow: 'hidden'}}>
              {istoric.map((i, idx) => {
                const tipColors = {
                  'revizie': G.green, 'reparatie': G.orange, 'ITP': G.blue,
                  'RCA': G.purple, 'CASCO': G.purple, 'altele': G.muted
                }
                const tipColor = tipColors[i.tip_revizie] || G.muted
                const isDoc = ['ITP', 'RCA', 'CASCO'].includes(i.tip_revizie)
                const expDays = i.data_expirare ? daysUntil(i.data_expirare) : null
                const expColor = expDays !== null ? (expDays < 0 ? G.red : expDays < 30 ? G.orange : expDays < 90 ? G.yellow : G.green) : G.muted
                return (
                  <div key={i.id} style={{
                    padding: '10px 14px',
                    borderBottom: idx < istoric.length - 1 ? `1px solid ${G.border}` : 'none',
                    display: 'grid',
                    gridTemplateColumns: '90px 90px 1fr auto',
                    gap: 12,
                    alignItems: 'center',
                    fontSize: 12
                  }}>
                    <div style={{fontFamily: 'monospace', color: G.text, fontWeight: 600}}>
                      {fmtDate(i.data_revizie)}
                    </div>
                    <span style={{
                      background: tipColor + '22', color: tipColor,
                      padding: '2px 8px', borderRadius: 12, fontSize: 10, fontWeight: 700,
                      letterSpacing: '.3px', textTransform: 'uppercase', textAlign: 'center'
                    }}>{i.tip_revizie}</span>
                    <div style={{color: G.muted, fontSize: 11}}>
                      {i.service_furnizor && <span style={{color: G.text}}>{i.service_furnizor}</span>}
                      {i.numar_document && <span style={{color: G.muted, fontFamily: 'monospace'}}> · {i.numar_document}</span>}
                      {!isDoc && i.ore_la_revizie && <> · {i.ore_la_revizie.toLocaleString('ro-RO')} ore</>}
                      {!isDoc && i.km_la_revizie && <> · {i.km_la_revizie.toLocaleString('ro-RO')} km</>}
                      {isDoc && i.data_expirare && (
                        <span style={{color: expColor, fontWeight: 700, marginLeft: 4}}>
                          {' · '}valabil până {fmtDate(i.data_expirare)}
                          {expDays !== null && expDays >= 0 && expDays <= 90 && ` (${expDays}z)`}
                          {expDays !== null && expDays < 0 && ` ⚠️ EXPIRAT`}
                        </span>
                      )}
                      {i.observatii && <div style={{marginTop: 2, fontStyle: 'italic'}}>{i.observatii}</div>}
                    </div>
                    <div style={{color: G.green, fontWeight: 700, fontVariantNumeric: 'tabular-nums', fontSize: 13}}>
                      {i.cost ? `${Number(i.cost).toLocaleString('ro-RO', {minimumFractionDigits: 2, maximumFractionDigits: 2})} RON` : '—'}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}
        
        {/* Widget analiză consum (rolling 5 alimentări) */}
        {mode === 'view' && alimentari.length >= 2 && activ?.norma_consum && (() => {
          const window = alimentari.slice(0, 5)  // ultimele 5 (deja sortate desc)
          const totalLitri = window.reduce((s, a) => s + Number(a.cantitate_litri || 0), 0)
          const oreEfectiveSum = window.reduce((s, a) => s + Number(a.ore_lucrate_efectiv || 0), 0)
          
          // Fallback: ore din bord (oldest - newest)
          const oreBordOldest = window[window.length-1]?.ore_la_alimentare
          const oreBordNewest = window[0]?.ore_la_alimentare
          const oreBordDif = (oreBordOldest && oreBordNewest && oreBordNewest > oreBordOldest) ? oreBordNewest - oreBordOldest : null
          
          const oreReale = oreEfectiveSum > 0 ? oreEfectiveSum : oreBordDif
          const sursaOre = oreEfectiveSum > 0 ? 'raport șantier' : 'citire bord'
          
          if (!oreReale) return (
            <div style={{padding: 12, background: G.surface, border: `1px dashed ${G.border2}`, borderRadius: 10, marginBottom: 14, fontSize: 12, color: G.muted}}>
              📊 <strong>Analiză consum indisponibilă</strong> — completează "Ore lucrate efectiv" sau "Ore bord" la alimentări pentru a putea calcula
            </div>
          )
          
          const norma = Number(activ.norma_consum)
          const consumTeoretic = oreReale * norma  // L
          const diferenta = totalLitri - consumTeoretic
          const procentDif = consumTeoretic > 0 ? (diferenta / consumTeoretic) * 100 : 0
          const prag = Number(activ.prag_alerta_consum) || 10
          const isSuspect = Math.abs(procentDif) > prag
          const isCritic = Math.abs(procentDif) > prag * 2
          
          // Direction: pozitivă = consumat MAI MULT decât teoretic (suspect furt), negativă = mai puțin (eficient)
          const isOverConsum = diferenta > 0
          
          let bg, color, emoji, status
          if (!isSuspect) {
            bg = G.greenDim; color = G.green; emoji = '✅'
            status = 'Consum în limite normale'
          } else if (isCritic) {
            bg = G.redDim; color = G.red; emoji = '🚨'
            status = isOverConsum ? 'CONSUM CRITIC — verifică urgent (posibil furt sau scurgere)' : 'Diferență critică — verifică citirile'
          } else {
            bg = G.yellowDim; color = G.orange; emoji = '⚠️'
            status = isOverConsum ? 'Consum peste prag — atenție' : 'Sub prag — verificare recomandată'
          }
          
          return (
            <div style={{
              ...S.card, padding: 14, marginBottom: 14,
              background: bg + 'aa',
              borderLeft: `4px solid ${color}`,
            }}>
              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10}}>
                <div style={{fontSize: 12, color, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.5px'}}>
                  📊 Analiză consum — ultimele {window.length} alimentări
                </div>
                <div style={{fontSize: 10, color: G.muted}}>
                  prag alertă: {prag}% · sursă ore: {sursaOre}
                </div>
              </div>
              
              <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 14, marginBottom: 10}}>
                <div>
                  <div style={{fontSize: 10, color: G.muted, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.4px'}}>Total alimentat</div>
                  <div style={{fontSize: 18, fontWeight: 800, color: G.text, fontVariantNumeric: 'tabular-nums'}}>
                    {totalLitri.toFixed(1)} <span style={{fontSize: 11, color: G.muted, fontWeight: 600}}>L</span>
                  </div>
                </div>
                <div>
                  <div style={{fontSize: 10, color: G.muted, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.4px'}}>Ore reale lucrate</div>
                  <div style={{fontSize: 18, fontWeight: 800, color: G.text, fontVariantNumeric: 'tabular-nums'}}>
                    {oreReale.toFixed(1)} <span style={{fontSize: 11, color: G.muted, fontWeight: 600}}>h</span>
                  </div>
                </div>
                <div>
                  <div style={{fontSize: 10, color: G.muted, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.4px'}}>Consum teoretic ({norma} {activ.unitate_norma || 'l/h'})</div>
                  <div style={{fontSize: 18, fontWeight: 800, color: G.text, fontVariantNumeric: 'tabular-nums'}}>
                    {consumTeoretic.toFixed(1)} <span style={{fontSize: 11, color: G.muted, fontWeight: 600}}>L</span>
                  </div>
                </div>
              </div>
              
              <div style={{padding: '10px 12px', background: G.bg + 'cc', borderRadius: 8, display: 'flex', alignItems: 'center', gap: 12}}>
                <div style={{fontSize: 22}}>{emoji}</div>
                <div style={{flex: 1}}>
                  <div style={{fontSize: 13, color, fontWeight: 700}}>
                    Diferență: {diferenta > 0 ? '+' : ''}{diferenta.toFixed(1)} L ({procentDif > 0 ? '+' : ''}{procentDif.toFixed(1)}%)
                  </div>
                  <div style={{fontSize: 11, color: G.muted, marginTop: 2}}>{status}</div>
                </div>
              </div>
            </div>
          )
        })()}
        
        {/* Istoric alimentări (doar în view) */}
        {mode === 'view' && alimentari.length > 0 && (
          <div style={{marginBottom: 14}}>
            <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8}}>
              <div style={{fontSize: 11, color: G.orange, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.6px'}}>
                ⛽ Alimentări combustibil ({alimentari.length})
              </div>
              <div style={{fontSize: 11, color: G.muted}}>
                Total: <strong style={{color: G.text}}>{alimentari.reduce((s, a) => s + Number(a.cantitate_litri || 0), 0).toFixed(2)} L</strong>
                {alimentari.some(a => a.pret_total) && <> · <strong style={{color: G.green}}>{alimentari.reduce((s, a) => s + Number(a.pret_total || 0), 0).toLocaleString('ro-RO', {minimumFractionDigits: 2, maximumFractionDigits: 2})} RON</strong></>}
              </div>
            </div>
            <div style={{...S.card, padding: 0, overflow: 'hidden'}}>
              {alimentari.slice(0, 10).map((a, idx) => (
                <div key={a.id} style={{
                  padding: '8px 14px',
                  borderBottom: idx < Math.min(alimentari.length, 10) - 1 ? `1px solid ${G.border}` : 'none',
                  display: 'grid',
                  gridTemplateColumns: '90px 70px 1fr auto',
                  gap: 12,
                  alignItems: 'center',
                  fontSize: 12
                }}>
                  <div style={{fontFamily: 'monospace', color: G.text, fontWeight: 600}}>
                    {fmtDate(a.data_alimentare)}
                  </div>
                  <div style={{color: G.orange, fontWeight: 700, fontVariantNumeric: 'tabular-nums'}}>
                    {Number(a.cantitate_litri).toFixed(1)} L
                  </div>
                  <div style={{color: G.muted, fontSize: 11}}>
                    {a.statie_combustibil && <span style={{color: G.text}}>{a.statie_combustibil}</span>}
                    {a.ore_la_alimentare && <> · {a.ore_la_alimentare.toLocaleString('ro-RO')} ore bord</>}
                    {a.km_la_alimentare && <> · {a.km_la_alimentare.toLocaleString('ro-RO')} km</>}
                    {a.ore_lucrate_efectiv && <> · {a.ore_lucrate_efectiv}h lucrate</>}
                    {a.observatii && <div style={{marginTop: 2, fontStyle: 'italic'}}>{a.observatii}</div>}
                  </div>
                  <div style={{color: G.green, fontWeight: 700, fontVariantNumeric: 'tabular-nums', fontSize: 13}}>
                    {a.pret_total ? `${Number(a.pret_total).toLocaleString('ro-RO', {minimumFractionDigits: 2, maximumFractionDigits: 2})} RON` : '—'}
                  </div>
                </div>
              ))}
              {alimentari.length > 10 && (
                <div style={{padding: '8px 14px', textAlign: 'center', fontSize: 11, color: G.muted, background: G.bg, borderTop: `1px solid ${G.border}`}}>
                  ... și încă {alimentari.length - 10} alimentări mai vechi
                </div>
              )}
            </div>
          </div>
        )}
        
        <div style={{display:'flex', justifyContent:'flex-end', gap: 8, paddingTop: 14, borderTop: `1px solid ${G.border}`}}>
          {mode !== 'view' && (
            <>
              <button onClick={onClose} style={{...S.btnS, fontSize: 13, color: G.muted}} disabled={saving}>Anulează</button>
              <button onClick={handleSave} disabled={saving} style={{...S.btnP, background: G.logistica, color: '#000', opacity: saving ? .6 : 1, cursor: saving ? 'wait' : 'pointer'}}>
                {saving ? '⏳ Se salvează...' : (mode === 'create' ? '✓ Creează activul' : '✓ Salvează modificările')}
              </button>
            </>
          )}
          {mode === 'view' && <button onClick={onClose} style={{...S.btnS, fontSize: 13}}>Închide</button>}
        </div>
      </div>
      
      {/* Modal mentenanță făcută (peste view) */}
      {showMent && (
        <MentenantaFacutaModal 
          activ={activ}
          plan={mentenanta}
          onClose={() => setShowMent(false)}
          onSaved={() => {
            setShowMent(false)
            supabase.from('logistica_mentenanta_istoric')
              .select('*').eq('active_id', activ.id)
              .order('data_revizie', { ascending: false })
              .then(({ data }) => setIstoric(data || []))
            onSaved()
          }}
          showToast={showToast}
        />
      )}
      
      {/* Modal alimentare combustibil */}
      {showAlim && (
        <AlimentareModal 
          activ={activ}
          rezervorGazpet={rezervorGazpet}
          sites={sites}
          pretMotorina={pretMotorina}
          onClose={() => setShowAlim(false)}
          onSaved={() => {
            setShowAlim(false)
            supabase.from('logistica_alimentari')
              .select('*').eq('active_id', activ.id)
              .order('data_alimentare', { ascending: false })
              .then(({ data }) => setAlimentari(data || []))
            onSaved()
          }}
          showToast={showToast}
        />
      )}
    </div>
  )
}

// ─── Pagina principală ───────────────────────────────────────────────────────
// ─── Bara de tab-uri pentru pagina Logistică ─────────────────────────────────
function TabsBar({ tab, setTab }) {
  const tabs = [
    { key: 'lista',     icon: '📋', label: 'Active' },
    { key: 'alimentari',icon: '⛽', label: 'Alimentări' },
    { key: 'documente', icon: '📎', label: 'Documente' },
    { key: 'service',   icon: '🔧', label: 'Service' },
    { key: 'tichete',   icon: '🎫', label: 'Tichete' },
  ]
  return (
    <div style={{display: 'flex', gap: 4, marginBottom: 14, padding: 4, background: G.surface, borderRadius: 10, border: `1px solid ${G.border}`, flexWrap: 'wrap'}}>
      {tabs.map(t => {
        const active = tab === t.key
        return (
          <button key={t.key} onClick={() => setTab(t.key)} style={{
            padding: '8px 14px',
            borderRadius: 7,
            border: 'none',
            cursor: 'pointer',
            fontSize: 13,
            fontWeight: active ? 700 : 500,
            background: active ? G.logistica + '22' : 'transparent',
            color: active ? G.logistica : G.muted,
            transition: 'all .15s',
            display: 'flex',
            alignItems: 'center',
            gap: 6,
          }}>
            <span style={{fontSize: 14}}>{t.icon}</span>
            {t.label}
          </button>
        )
      })}
    </div>
  )
}

// ════════════════════════════════════════════════════════════════════════════
// TAB DOCUMENTE — Hub cu 4 sub-tab-uri
// ════════════════════════════════════════════════════════════════════════════

function DocStatusBadge({ zile }) {
  if (zile === null || zile === undefined) {
    return <span style={{fontSize:11, padding:'2px 8px', borderRadius:4, background:G.dim+'22', color:G.dim, fontWeight:600}}>—</span>
  }
  if (zile < 0) {
    return <span style={{fontSize:11, padding:'2px 8px', borderRadius:4, background:G.red+'22', color:G.red, fontWeight:700}}>EXPIRAT ({Math.abs(zile)}z)</span>
  }
  if (zile <= 30) {
    return <span style={{fontSize:11, padding:'2px 8px', borderRadius:4, background:G.orange+'22', color:G.orange, fontWeight:700}}>{zile}z</span>
  }
  if (zile <= 90) {
    return <span style={{fontSize:11, padding:'2px 8px', borderRadius:4, background:G.yellow+'22', color:G.yellow, fontWeight:600}}>{zile}z</span>
  }
  return <span style={{fontSize:11, padding:'2px 8px', borderRadius:4, background:G.green+'22', color:G.green, fontWeight:600}}>{zile}z</span>
}

function DocumenteSubTabs({ subtab, setSubtab, kpiAlerte }) {
  const tabs = [
    { key: 'flota',    icon: '🚛', label: 'Flotă' },
    { key: 'personal', icon: '👤', label: 'Personal' },
    { key: 'amc',      icon: '🔬', label: 'Echipamente AMC' },
    { key: 'alerte',   icon: '🔔', label: 'Alerte', badge: kpiAlerte },
  ]
  return (
    <div style={{display:'flex', gap:6, marginBottom:14, padding:4, background:G.bg, borderRadius:9, border:`1px solid ${G.border}`, width:'fit-content', flexWrap:'wrap'}}>
      {tabs.map(t => {
        const a = subtab === t.key
        return (
          <button key={t.key} onClick={()=>setSubtab(t.key)} style={{
            padding:'8px 14px', borderRadius:6, border:'none',
            cursor:'pointer', fontSize:13,
            fontWeight: a?700:500,
            background: a ? G.logistica + '33' : 'transparent',
            color: a ? G.logistica : G.muted,
            display:'flex', alignItems:'center', gap:6,
            transition:'all .15s',
          }}>
            <span style={{fontSize:14}}>{t.icon}</span>
            {t.label}
            {t.badge > 0 && (
              <span style={{
                fontSize:10, padding:'1px 6px', borderRadius:8,
                background: a ? G.red : G.red+'33',
                color: a ? 'white' : G.red, fontWeight:700, marginLeft:2
              }}>{t.badge}</span>
            )}
          </button>
        )
      })}
    </div>
  )
}

// ─── DocumenteTab (parent) ──────────────────────────────────────────────────
function DocumenteTab({ active, accessLevel, profile, showToast }) {
  const [subtab, setSubtab] = useState('flota')
  const [kpiAlerte, setKpiAlerte] = useState(0)
  
  // Fetch count alerte (expirate + 30z) pentru badge
  useEffect(() => {
    const fetchAlerteCount = async () => {
      const in30 = new Date(Date.now() + 30*86400000).toISOString().split('T')[0]
      const [{ count: flotaCnt }, { count: hrCnt }] = await Promise.all([
        supabase.from('logistica_documente').select('id', { count: 'exact', head: true })
          .eq('entitate_tip', 'activ')
          .lte('data_expirare', in30),
        supabase.from('v_hr_autorizatii_status').select('id', { count: 'exact', head: true })
          .eq('fara_expirare', false)
          .lte('data_expirare', in30),
      ])
      setKpiAlerte((flotaCnt || 0) + (hrCnt || 0))
    }
    fetchAlerteCount().catch(()=>{})
  }, [subtab])
  
  return (
    <>
      <DocumenteSubTabs subtab={subtab} setSubtab={setSubtab} kpiAlerte={kpiAlerte} />
      {subtab === 'flota'    && <DocumenteFlotaPage    active={active} accessLevel={accessLevel} showToast={showToast} />}
      {subtab === 'personal' && <DocumentePersonalPage showToast={showToast} />}
      {subtab === 'amc'      && <DocumenteAMCPage />}
      {subtab === 'alerte'   && <DocumenteAlertePage   active={active} />}
    </>
  )
}

// ─── Sub-tab Flotă: Documente vehicule/utilaje ─────────────────────────────
function DocumenteFlotaPage({ active, accessLevel, showToast }) {
  const [docs, setDocs] = useState([])
  const [tipuri, setTipuri] = useState([])
  const [load, setLoad] = useState(true)
  const [search, setSearch] = useState('')
  const [statusF, setStatusF] = useState('Toate')
  const [tipF, setTipF] = useState('Toate')
  const [modal, setModal] = useState(null)  // {mode:'create'|'edit', doc?}
  
  const canEdit = accessLevel === 'admin' || accessLevel === 'editor'
  
  useEffect(() => {
    fetchAll()
  }, [])
  
  const fetchAll = async () => {
    setLoad(true)
    const [docsRes, tipuriRes] = await Promise.all([
      supabase.from('logistica_documente')
        .select('*, logistica_tipuri_documente(nume)')
        .eq('entitate_tip', 'activ')
        .order('data_expirare', { ascending: true }),
      supabase.from('logistica_tipuri_documente')
        .select('*').eq('activ', true).order('nume')
    ])
    setDocs(docsRes.data || [])
    setTipuri(tipuriRes.data || [])
    setLoad(false)
  }
  
  // Map activ_id → label
  const activMap = useMemo(() => {
    const m = {}
    active.forEach(a => {
      const id = a.cod_intern || a.nr_inmatriculare || `#${a.id}`
      const desc = [a.marca, a.model].filter(Boolean).join(' ')
      m[a.id] = { id_label: id, desc, cod: a.cod_intern, plac: a.nr_inmatriculare }
    })
    return m
  }, [active])
  
  // Enrichment + filtrare
  const enriched = useMemo(() => {
    const today = new Date()
    return docs.map(d => {
      const a = activMap[d.entitate_id] || {}
      const expDate = d.data_expirare ? new Date(d.data_expirare) : null
      const zile = expDate ? Math.ceil((expDate - today) / 86400000) : null
      const status = zile === null ? 'fara_data' : 
                     zile < 0 ? 'expirat' : 
                     zile <= 30 ? 'expira_30z' : 
                     zile <= 90 ? 'expira_90z' : 'ok'
      return { ...d, activ: a, zile, status }
    })
  }, [docs, activMap])
  
  const filtered = useMemo(() => {
    return enriched.filter(d => {
      if (search) {
        const s = search.toLowerCase()
        const hay = [d.activ?.id_label, d.activ?.desc, d.logistica_tipuri_documente?.nume, d.numar_document].filter(Boolean).join(' ').toLowerCase()
        if (!hay.includes(s)) return false
      }
      if (tipF !== 'Toate' && d.logistica_tipuri_documente?.nume !== tipF) return false
      if (statusF === 'Expirate' && d.status !== 'expirat') return false
      if (statusF === 'Expiră 30z' && d.status !== 'expira_30z') return false
      if (statusF === 'Expiră 90z' && d.status !== 'expira_90z') return false
      if (statusF === 'OK' && d.status !== 'ok') return false
      return true
    })
  }, [enriched, search, statusF, tipF])
  
  // KPI
  const kpi = useMemo(() => ({
    total: enriched.length,
    expirate: enriched.filter(d => d.status === 'expirat').length,
    expira_30: enriched.filter(d => d.status === 'expira_30z').length,
    expira_90: enriched.filter(d => d.status === 'expira_90z').length,
    ok: enriched.filter(d => d.status === 'ok').length,
  }), [enriched])
  
  const handleDelete = async (id) => {
    if (!confirm('Sigur ștergi acest document?')) return
    const { error } = await supabase.from('logistica_documente').delete().eq('id', id)
    if (error) { showToast('Eroare la ștergere: '+error.message, 'error'); return }
    showToast('✓ Document șters', 'success')
    fetchAll()
  }
  
  if (load) return <div style={{...S.card, padding:30, textAlign:'center', color:G.muted}}>⏳ Se încarcă documente...</div>
  
  return (
    <>
      {/* KPI cards */}
      <div style={{display:'flex', gap:12, marginBottom:14, flexWrap:'wrap'}}>
        <KPICard icon="📄" label="Total docs flotă" value={kpi.total} color={G.blue} />
        <KPICard icon="⚠" label="Expirate" value={kpi.expirate} color={G.red} />
        <KPICard icon="⏰" label="Expiră 30z" value={kpi.expira_30} color={G.orange} />
        <KPICard icon="📅" label="Expiră 90z" value={kpi.expira_90} color={G.yellow} />
        <KPICard icon="✓" label="Valabile" value={kpi.ok} color={G.green} />
      </div>
      
      {/* Filtre */}
      <div style={{...S.card, padding:12, marginBottom:14, display:'flex', gap:10, flexWrap:'wrap', alignItems:'center'}}>
        <input
          type="text"
          placeholder="🔍 Caută vehicul, tip, număr..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{...S.input, flex:'1 1 240px', minWidth:240}}
        />
        <select value={tipF} onChange={e => setTipF(e.target.value)} style={{...S.input, width:'auto'}}>
          <option>Toate</option>
          {tipuri.map(t => <option key={t.id}>{t.nume}</option>)}
        </select>
        <div style={{display:'flex', gap:4}}>
          {['Toate','Expirate','Expiră 30z','Expiră 90z','OK'].map(s => (
            <button key={s} onClick={() => setStatusF(s)} style={{
              ...S.btnS, padding:'6px 12px', fontSize:12,
              background: statusF===s ? G.logistica+'22' : 'transparent',
              color: statusF===s ? G.logistica : G.muted,
              borderColor: statusF===s ? G.logistica+'55' : G.border,
            }}>{s}</button>
          ))}
        </div>
        {canEdit && (
          <button onClick={() => setModal({mode:'create'})} style={{...S.btnP, marginLeft:'auto'}}>
            + Adaugă document
          </button>
        )}
      </div>
      
      {/* Tabel */}
      {filtered.length === 0 ? (
        <div style={{...S.card, padding:40, textAlign:'center', color:G.muted}}>
          {docs.length === 0 ? 'Niciun document înregistrat încă.' : `Nu există documente care să respecte filtrele aplicate (${enriched.length} total).`}
        </div>
      ) : (
        <div style={{...S.card, overflow:'hidden'}}>
          <div style={{maxHeight:600, overflow:'auto'}}>
            <table style={{width:'100%', borderCollapse:'collapse', fontSize:13}}>
              <thead style={{position:'sticky', top:0, background:G.surface, zIndex:1}}>
                <tr style={{borderBottom:`2px solid ${G.border2}`}}>
                  <th style={{padding:'10px 12px', textAlign:'left', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase', letterSpacing:.5}}>Vehicul/Utilaj</th>
                  <th style={{padding:'10px 12px', textAlign:'left', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase', letterSpacing:.5}}>Tip doc</th>
                  <th style={{padding:'10px 12px', textAlign:'left', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase', letterSpacing:.5}}>Număr</th>
                  <th style={{padding:'10px 12px', textAlign:'left', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase', letterSpacing:.5}}>Emis</th>
                  <th style={{padding:'10px 12px', textAlign:'left', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase', letterSpacing:.5}}>Expiră</th>
                  <th style={{padding:'10px 12px', textAlign:'center', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase', letterSpacing:.5}}>Status</th>
                  {canEdit && <th style={{padding:'10px 12px', textAlign:'right', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase', letterSpacing:.5}}>Acțiuni</th>}
                </tr>
              </thead>
              <tbody>
                {filtered.map((d, i) => (
                  <tr key={d.id} style={{borderBottom:`1px solid ${G.border}`, background: i%2===0 ? 'transparent' : G.bg+'77'}}>
                    <td style={{padding:'9px 12px'}}>
                      <div style={{fontFamily:'monospace', fontSize:12, color: d.activ.cod ? G.blue : G.purple, fontWeight:700}}>
                        {d.activ.id_label || `#${d.entitate_id}`}
                      </div>
                      <div style={{fontSize:11, color:G.muted}}>{d.activ.desc || '—'}</div>
                    </td>
                    <td style={{padding:'9px 12px', fontWeight:600}}>{d.logistica_tipuri_documente?.nume || '—'}</td>
                    <td style={{padding:'9px 12px', fontFamily:'monospace', fontSize:12, color:G.muted}}>{d.numar_document || '—'}</td>
                    <td style={{padding:'9px 12px', color:G.muted}}>{fmtDate(d.data_emitere)}</td>
                    <td style={{padding:'9px 12px', fontWeight:600}}>{fmtDate(d.data_expirare)}</td>
                    <td style={{padding:'9px 12px', textAlign:'center'}}><DocStatusBadge zile={d.zile} /></td>
                    {canEdit && (
                      <td style={{padding:'9px 12px', textAlign:'right', whiteSpace:'nowrap'}}>
                        <button onClick={() => setModal({mode:'edit', doc:d})} style={{...S.btnS, padding:'4px 10px', fontSize:11, marginRight:6}}>✏️</button>
                        <button onClick={() => handleDelete(d.id)} style={{...S.btnS, padding:'4px 10px', fontSize:11, color:G.red, borderColor:G.red+'55'}}>🗑</button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div style={{padding:'8px 14px', borderTop:`1px solid ${G.border}`, fontSize:11, color:G.muted, background:G.bg}}>
            {filtered.length} din {enriched.length} documente afișate
          </div>
        </div>
      )}
      
      {modal && (
        <DocumentFlotaModal
          mode={modal.mode}
          doc={modal.doc}
          active={active}
          tipuri={tipuri}
          onClose={() => setModal(null)}
          onSaved={() => { setModal(null); fetchAll() }}
          showToast={showToast}
        />
      )}
    </>
  )
}

// ─── Modal Add/Edit document flotă ───────────────────────────────────────────
function DocumentFlotaModal({ mode, doc, active, tipuri, onClose, onSaved, showToast }) {
  const [form, setForm] = useState({
    entitate_id: doc?.entitate_id || '',
    tip_id: doc?.tip_id || '',
    numar_document: doc?.numar_document || '',
    data_emitere: doc?.data_emitere || '',
    data_expirare: doc?.data_expirare || '',
    emitent: doc?.emitent || '',
    cost: doc?.cost || '',
    observatii: doc?.observatii || '',
  })
  const [saving, setSaving] = useState(false)
  const [pdfFile, setPdfFile] = useState(null)
  const [searchActiv, setSearchActiv] = useState('')
  
  const setField = (k, v) => setForm(f => ({ ...f, [k]: v }))
  
  // Auto-calculate data_expirare când se selectează tip_id și se setează data_emitere
  useEffect(() => {
    if (form.tip_id && form.data_emitere && !doc) {
      const tip = tipuri.find(t => t.id === Number(form.tip_id))
      if (tip?.perioada_default_zile) {
        const d = new Date(form.data_emitere)
        d.setDate(d.getDate() + tip.perioada_default_zile)
        setField('data_expirare', d.toISOString().split('T')[0])
      }
    }
  }, [form.tip_id, form.data_emitere])
  
  const activeFiltered = useMemo(() => {
    if (!searchActiv) return active.slice(0, 50)
    const s = searchActiv.toLowerCase()
    return active.filter(a => {
      const lbl = [a.cod_intern, a.nr_inmatriculare, a.marca, a.model].filter(Boolean).join(' ').toLowerCase()
      return lbl.includes(s)
    }).slice(0, 50)
  }, [searchActiv, active])
  
  const selectedActiv = active.find(a => a.id === Number(form.entitate_id))
  
  const handleSave = async () => {
    if (!form.entitate_id) { showToast('Selectează vehicul/utilaj', 'error'); return }
    if (!form.tip_id) { showToast('Selectează tip document', 'error'); return }
    if (!form.data_expirare) { showToast('Data expirării obligatorie', 'error'); return }
    
    setSaving(true)
    const { data: { user } } = await supabase.auth.getUser()
    
    let pdfUrl = doc?.pdf_url || null
    if (pdfFile) {
      const ext = pdfFile.name.split('.').pop()
      const path = `${form.entitate_id}/${Date.now()}.${ext}`
      const { error: upErr } = await supabase.storage.from('documente-flota').upload(path, pdfFile)
      if (upErr) { setSaving(false); showToast('Eroare upload PDF: '+upErr.message, 'error'); return }
      pdfUrl = path
    }
    
    const payload = {
      entitate_tip: 'activ',
      entitate_id: Number(form.entitate_id),
      active_id: Number(form.entitate_id),  // backwards compat
      tip_id: Number(form.tip_id),
      numar_document: form.numar_document.trim() || null,
      data_emitere: form.data_emitere || null,
      data_expirare: form.data_expirare,
      emitent: form.emitent.trim() || null,
      cost: form.cost ? Number(form.cost) : null,
      observatii: form.observatii.trim() || null,
      pdf_url: pdfUrl,
      created_by: user?.id,
    }
    
    let result
    if (mode === 'create') {
      result = await supabase.from('logistica_documente').insert(payload).select().single()
    } else {
      result = await supabase.from('logistica_documente').update(payload).eq('id', doc.id).select().single()
    }
    
    setSaving(false)
    if (result.error) { showToast('Eroare: '+result.error.message, 'error'); return }
    showToast(mode==='create' ? '✓ Document adăugat' : '✓ Document actualizat', 'success')
    onSaved()
  }
  
  return (
    <div style={{position:'fixed', inset:0, background:'rgba(0,0,0,.7)', zIndex:1000, display:'flex', alignItems:'center', justifyContent:'center', padding:20}} onClick={onClose}>
      <div onClick={e=>e.stopPropagation()} style={{
        background:G.surface, border:`1px solid ${G.border2}`, borderRadius:14,
        padding:24, width:'100%', maxWidth:560, maxHeight:'90vh', overflow:'auto'
      }}>
        <div style={{fontSize:18, fontWeight:800, color:G.text, marginBottom:18}}>
          {mode==='create' ? '📄 Adaugă document' : '✏️ Editare document'}
        </div>
        
        {/* Activ */}
        <div style={{marginBottom:14}}>
          <div style={{fontSize:11, color:G.logistica, fontWeight:700, textTransform:'uppercase', letterSpacing:.5, marginBottom:6}}>
            Vehicul / Utilaj *
          </div>
          {selectedActiv ? (
            <div style={{padding:'8px 12px', background:G.bg, border:`1px solid ${G.border2}`, borderRadius:7, display:'flex', alignItems:'center', justifyContent:'space-between'}}>
              <div>
                <span style={{fontFamily:'monospace', fontWeight:700, color:G.blue}}>{selectedActiv.cod_intern || selectedActiv.nr_inmatriculare}</span>
                <span style={{color:G.muted, marginLeft:8}}>{[selectedActiv.marca, selectedActiv.model].filter(Boolean).join(' ')}</span>
              </div>
              {mode==='create' && (
                <button onClick={() => setField('entitate_id', '')} style={{...S.btnS, padding:'4px 10px', fontSize:11}}>Schimbă</button>
              )}
            </div>
          ) : (
            <>
              <input type="text" placeholder="🔍 Caută cod TST, plăcuță, marcă..." value={searchActiv} onChange={e=>setSearchActiv(e.target.value)} style={{...S.input, marginBottom:6}} />
              <div style={{maxHeight:200, overflow:'auto', border:`1px solid ${G.border}`, borderRadius:7}}>
                {activeFiltered.map(a => (
                  <div key={a.id} onClick={() => setField('entitate_id', a.id)} style={{
                    padding:'7px 12px', borderBottom:`1px solid ${G.border}`, cursor:'pointer',
                    fontSize:13,
                  }} onMouseEnter={e => e.currentTarget.style.background = G.bg} onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                    <span style={{fontFamily:'monospace', fontWeight:700, color: a.cod_intern ? G.blue : G.purple}}>
                      {a.cod_intern || a.nr_inmatriculare || `#${a.id}`}
                    </span>
                    <span style={{color:G.muted, marginLeft:8, fontSize:12}}>{[a.marca, a.model].filter(Boolean).join(' ')}</span>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
        
        {/* Tip document */}
        <FieldSelect label="Tip document *" value={form.tip_id} onChange={v=>setField('tip_id',v)}
          options={[{value:'', label:'— alege —'}, ...tipuri.map(t => ({value:t.id, label:t.nume}))]}
        />
        
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginTop:12}}>
          <div>
            <div style={{fontSize:11, color:G.logistica, fontWeight:700, textTransform:'uppercase', letterSpacing:.5, marginBottom:6}}>Data emitere</div>
            <input type="date" value={form.data_emitere} onChange={e=>setField('data_emitere', e.target.value)} style={S.input} />
          </div>
          <div>
            <div style={{fontSize:11, color:G.logistica, fontWeight:700, textTransform:'uppercase', letterSpacing:.5, marginBottom:6}}>Data expirare *</div>
            <input type="date" value={form.data_expirare} onChange={e=>setField('data_expirare', e.target.value)} style={S.input} />
          </div>
        </div>
        
        <div style={{marginTop:12}}>
          <FieldText label="Număr document" value={form.numar_document} onChange={v=>setField('numar_document',v)} placeholder="ex: RCA12345" />
        </div>
        <div style={{marginTop:12}}>
          <FieldText label="Emitent" value={form.emitent} onChange={v=>setField('emitent',v)} placeholder="ex: Allianz, Service ITP Ploiești..." />
        </div>
        <div style={{marginTop:12}}>
          <FieldText label="Cost (RON)" type="number" value={form.cost} onChange={v=>setField('cost',v)} />
        </div>
        
        {/* PDF upload */}
        <div style={{marginTop:12}}>
          <div style={{fontSize:11, color:G.logistica, fontWeight:700, textTransform:'uppercase', letterSpacing:.5, marginBottom:6}}>PDF document</div>
          <input type="file" accept="application/pdf,image/*" onChange={e=>setPdfFile(e.target.files[0])} style={{...S.input, padding:6, fontSize:12}} />
          {doc?.pdf_url && !pdfFile && (
            <div style={{fontSize:11, color:G.green, marginTop:4}}>✓ PDF existent: {doc.pdf_url.split('/').pop()}</div>
          )}
        </div>
        
        <div style={{marginTop:12}}>
          <FieldTextarea label="Observații" value={form.observatii} onChange={v=>setField('observatii',v)} rows={2} />
        </div>
        
        <div style={{display:'flex', gap:10, justifyContent:'flex-end', marginTop:18, paddingTop:14, borderTop:`1px solid ${G.border}`}}>
          <button onClick={onClose} disabled={saving} style={{...S.btnS, fontSize:13}}>Anulează</button>
          <button onClick={handleSave} disabled={saving} style={{...S.btnP, opacity: saving ? .6 : 1, cursor: saving?'wait':'pointer'}}>
            {saving ? '⏳ Se salvează...' : (mode==='create' ? '✓ Adaugă' : '✓ Salvează')}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Sub-tab Personal: Pull READ-ONLY din hr_autorizatii ────────────────────
function DocumentePersonalPage({ showToast }) {
  const [auts, setAuts] = useState([])
  const [load, setLoad] = useState(true)
  const [search, setSearch] = useState('')
  const [statusF, setStatusF] = useState('Toate')
  
  useEffect(() => {
    fetchAuts()
  }, [])
  
  const fetchAuts = async () => {
    setLoad(true)
    // Folosim view-ul gata calculat din modulul HR
    const { data, error } = await supabase
      .from('v_hr_autorizatii_status')
      .select('*')
      .order('data_expirare', { ascending: true, nullsFirst: false })
    if (error) { showToast('Eroare: '+error.message, 'error') }
    setAuts(data || [])
    setLoad(false)
  }
  
  const enriched = useMemo(() => {
    return auts.map(a => ({
      ...a,
      angajat: a.employee_name || '—',
      dept: a.departament_hr,
      tip_label: a.tip_denumire || a.tip_cod || '—',
      numar: a.numar_autorizatie,
      zile: a.zile_pana_expirare,
      status: a.fara_expirare ? 'fara_data' : a.status,
    }))
  }, [auts])
  
  const filtered = useMemo(() => {
    return enriched.filter(a => {
      if (search) {
        const s = search.toLowerCase()
        const hay = [a.angajat, a.tip_label, a.numar, a.dept].filter(Boolean).join(' ').toLowerCase()
        if (!hay.includes(s)) return false
      }
      if (statusF === 'Expirate' && a.status !== 'expirat') return false
      if (statusF === 'Expiră 30z' && a.status !== 'expira_30z') return false
      if (statusF === 'Expiră 90z' && a.status !== 'expira_90z') return false
      if (statusF === 'OK' && a.status !== 'ok') return false
      if (statusF === 'Fără expirare' && a.status !== 'fara_data') return false
      return true
    })
  }, [enriched, search, statusF])
  
  const kpi = useMemo(() => ({
    total: enriched.length,
    expirate: enriched.filter(a => a.status === 'expirat').length,
    expira_30: enriched.filter(a => a.status === 'expira_30z').length,
    fara_data: enriched.filter(a => a.status === 'fara_data').length,
  }), [enriched])
  
  if (load) return <div style={{...S.card, padding:30, textAlign:'center', color:G.muted}}>⏳ Se încarcă autorizații...</div>
  
  return (
    <>
      <div style={{...S.card, padding:'10px 14px', marginBottom:14, background:G.blue+'11', border:`1px solid ${G.blue}33`, fontSize:12, color:G.text}}>
        ℹ️ <strong>Citire READ-ONLY</strong> din modulul HR. Pentru CRUD autorizații folosește <strong>HR → Autorizații</strong>.
      </div>
      
      <div style={{display:'flex', gap:12, marginBottom:14, flexWrap:'wrap'}}>
        <KPICard icon="📋" label="Total autorizații" value={kpi.total} color={G.blue} />
        <KPICard icon="⚠" label="Expirate" value={kpi.expirate} color={G.red} />
        <KPICard icon="⏰" label="Expiră 30z" value={kpi.expira_30} color={G.orange} />
        <KPICard icon="∞" label="Fără expirare" value={kpi.fara_data} color={G.muted} />
      </div>
      
      <div style={{...S.card, padding:12, marginBottom:14, display:'flex', gap:10, flexWrap:'wrap', alignItems:'center'}}>
        <input type="text" placeholder="🔍 Caută angajat, tip, număr, dept..." value={search} onChange={e=>setSearch(e.target.value)} style={{...S.input, flex:'1 1 240px', minWidth:240}} />
        <div style={{display:'flex', gap:4}}>
          {['Toate','Expirate','Expiră 30z','Expiră 90z','OK','Fără expirare'].map(s => (
            <button key={s} onClick={() => setStatusF(s)} style={{
              ...S.btnS, padding:'6px 12px', fontSize:12,
              background: statusF===s ? G.logistica+'22' : 'transparent',
              color: statusF===s ? G.logistica : G.muted,
              borderColor: statusF===s ? G.logistica+'55' : G.border,
            }}>{s}</button>
          ))}
        </div>
      </div>
      
      {filtered.length === 0 ? (
        <div style={{...S.card, padding:40, textAlign:'center', color:G.muted}}>Nicio autorizație care să respecte filtrele.</div>
      ) : (
        <div style={{...S.card, overflow:'hidden'}}>
          <div style={{maxHeight:600, overflow:'auto'}}>
            <table style={{width:'100%', borderCollapse:'collapse', fontSize:13}}>
              <thead style={{position:'sticky', top:0, background:G.surface, zIndex:1}}>
                <tr style={{borderBottom:`2px solid ${G.border2}`}}>
                  <th style={{padding:'10px 12px', textAlign:'left', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase', letterSpacing:.5}}>Angajat</th>
                  <th style={{padding:'10px 12px', textAlign:'left', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase', letterSpacing:.5}}>Departament</th>
                  <th style={{padding:'10px 12px', textAlign:'left', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase', letterSpacing:.5}}>Tip autorizație</th>
                  <th style={{padding:'10px 12px', textAlign:'left', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase', letterSpacing:.5}}>Număr</th>
                  <th style={{padding:'10px 12px', textAlign:'left', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase', letterSpacing:.5}}>Expiră</th>
                  <th style={{padding:'10px 12px', textAlign:'center', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase', letterSpacing:.5}}>Status</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((a, i) => (
                  <tr key={a.id} style={{borderBottom:`1px solid ${G.border}`, background: i%2===0 ? 'transparent' : G.bg+'77'}}>
                    <td style={{padding:'9px 12px', fontWeight:600}}>{a.angajat}</td>
                    <td style={{padding:'9px 12px', color:G.muted, fontSize:12}}>{a.dept || '—'}</td>
                    <td style={{padding:'9px 12px'}}>{a.tip_label}</td>
                    <td style={{padding:'9px 12px', fontFamily:'monospace', fontSize:12, color:G.muted}}>{a.numar || '—'}</td>
                    <td style={{padding:'9px 12px'}}>{a.fara_expirare ? <span style={{color:G.muted, fontStyle:'italic'}}>fără expirare</span> : fmtDate(a.data_expirare)}</td>
                    <td style={{padding:'9px 12px', textAlign:'center'}}><DocStatusBadge zile={a.fara_expirare ? null : a.zile} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div style={{padding:'8px 14px', borderTop:`1px solid ${G.border}`, fontSize:11, color:G.muted, background:G.bg}}>
            {filtered.length} din {enriched.length} autorizații
          </div>
        </div>
      )}
    </>
  )
}

// ─── Sub-tab AMC (placeholder) ──────────────────────────────────────────────
function DocumenteAMCPage() {
  return (
    <div style={{...S.card, padding:60, textAlign:'center'}}>
      <div style={{fontSize:64, marginBottom:14, opacity:.4}}>🔬</div>
      <div style={{fontSize:22, fontWeight:800, color:G.text, marginBottom:6}}>Echipamente AMC</div>
      <div style={{fontSize:13, color:G.muted, marginBottom:18, maxWidth:480, margin:'0 auto 18px'}}>
        Aparate de Măsură și Control: manometre, izotest, EIP, buletine etalonare, PRAM (verificare instalații electrice).
      </div>
      <div style={{display:'inline-block', padding:'6px 14px', background:G.yellow+'22', color:G.yellow, fontSize:11, fontWeight:700, borderRadius:14, letterSpacing:.5}}>
        🚧 FAZA 2
      </div>
    </div>
  )
}

// ─── Sub-tab Alerte (combinate flotă + HR) ──────────────────────────────────
function DocumenteAlertePage({ active }) {
  const [flotaDocs, setFlotaDocs] = useState([])
  const [hrAuts, setHrAuts] = useState([])
  const [load, setLoad] = useState(true)
  const [sursa, setSursa] = useState('Toate')  // Toate | Flotă | HR
  const [statusF, setStatusF] = useState('Toate')  // Toate | Expirate | 30z | 90z
  
  useEffect(() => {
    const fetchAll = async () => {
      setLoad(true)
      const in90 = new Date(Date.now() + 90*86400000).toISOString().split('T')[0]
      const [flota, hr] = await Promise.all([
        supabase.from('logistica_documente')
          .select('*, logistica_tipuri_documente(nume)')
          .eq('entitate_tip', 'activ')
          .lte('data_expirare', in90)
          .order('data_expirare', { ascending: true }),
        supabase.from('v_hr_autorizatii_status')
          .select('*')
          .eq('fara_expirare', false)
          .lte('data_expirare', in90)
          .order('data_expirare', { ascending: true })
      ])
      setFlotaDocs(flota.data || [])
      setHrAuts(hr.data || [])
      setLoad(false)
    }
    fetchAll().catch(()=>setLoad(false))
  }, [])
  
  const activMap = useMemo(() => {
    const m = {}
    active.forEach(a => {
      m[a.id] = {
        label: a.cod_intern || a.nr_inmatriculare || `#${a.id}`,
        desc: [a.marca, a.model].filter(Boolean).join(' ')
      }
    })
    return m
  }, [active])
  
  const merged = useMemo(() => {
    const today = new Date()
    const flotaItems = flotaDocs.map(d => {
      const a = activMap[d.entitate_id] || {}
      const zile = Math.ceil((new Date(d.data_expirare) - today) / 86400000)
      return {
        id: 'f' + d.id, sursa: 'Flotă',
        target: a.label || `#${d.entitate_id}`,
        target_desc: a.desc || '',
        tip: d.logistica_tipuri_documente?.nume || '?',
        numar: d.numar_document,
        data_expirare: d.data_expirare,
        zile,
        status: zile < 0 ? 'expirat' : zile <= 30 ? 'expira_30z' : 'expira_90z'
      }
    })
    const hrItems = hrAuts.map(a => {
      const zile = Math.ceil((new Date(a.data_expirare) - today) / 86400000)
      return {
        id: 'h' + a.id, sursa: 'HR',
        target: a.employee_name || '—',
        target_desc: a.departament_hr || '',
        tip: a.tip_denumire || a.tip_cod || '?',
        numar: a.numar_autorizatie,
        data_expirare: a.data_expirare,
        zile,
        status: zile < 0 ? 'expirat' : zile <= 30 ? 'expira_30z' : 'expira_90z'
      }
    })
    return [...flotaItems, ...hrItems].sort((a,b) => a.zile - b.zile)
  }, [flotaDocs, hrAuts, activMap])
  
  const filtered = useMemo(() => {
    return merged.filter(m => {
      if (sursa !== 'Toate' && m.sursa !== sursa) return false
      if (statusF === 'Expirate' && m.status !== 'expirat') return false
      if (statusF === 'Expiră 30z' && m.status !== 'expira_30z') return false
      if (statusF === 'Expiră 90z' && m.status !== 'expira_90z') return false
      return true
    })
  }, [merged, sursa, statusF])
  
  const kpi = useMemo(() => ({
    total: merged.length,
    flota: merged.filter(m => m.sursa === 'Flotă').length,
    hr: merged.filter(m => m.sursa === 'HR').length,
    expirate: merged.filter(m => m.status === 'expirat').length,
    expira_30: merged.filter(m => m.status === 'expira_30z').length,
  }), [merged])
  
  if (load) return <div style={{...S.card, padding:30, textAlign:'center', color:G.muted}}>⏳ Se încarcă alerte...</div>
  
  return (
    <>
      <div style={{display:'flex', gap:12, marginBottom:14, flexWrap:'wrap'}}>
        <KPICard icon="🔔" label="Total alerte" value={kpi.total} color={G.blue} />
        <KPICard icon="🚛" label="Flotă" value={kpi.flota} color={G.logistica} />
        <KPICard icon="👤" label="HR" value={kpi.hr} color={G.purple} />
        <KPICard icon="⚠" label="Expirate" value={kpi.expirate} color={G.red} />
        <KPICard icon="⏰" label="Expiră 30z" value={kpi.expira_30} color={G.orange} />
      </div>
      
      <div style={{...S.card, padding:12, marginBottom:14, display:'flex', gap:10, flexWrap:'wrap', alignItems:'center'}}>
        <span style={{fontSize:11, color:G.muted, fontWeight:600}}>SURSĂ:</span>
        {['Toate','Flotă','HR'].map(s => (
          <button key={s} onClick={() => setSursa(s)} style={{
            ...S.btnS, padding:'6px 12px', fontSize:12,
            background: sursa===s ? G.purple+'22' : 'transparent',
            color: sursa===s ? G.purple : G.muted,
            borderColor: sursa===s ? G.purple+'55' : G.border,
          }}>{s}</button>
        ))}
        <span style={{fontSize:11, color:G.muted, fontWeight:600, marginLeft:14}}>STATUS:</span>
        {['Toate','Expirate','Expiră 30z','Expiră 90z'].map(s => (
          <button key={s} onClick={() => setStatusF(s)} style={{
            ...S.btnS, padding:'6px 12px', fontSize:12,
            background: statusF===s ? G.logistica+'22' : 'transparent',
            color: statusF===s ? G.logistica : G.muted,
            borderColor: statusF===s ? G.logistica+'55' : G.border,
          }}>{s}</button>
        ))}
      </div>
      
      {filtered.length === 0 ? (
        <div style={{...S.card, padding:40, textAlign:'center', color:G.muted}}>
          {merged.length === 0 ? '🎉 Nicio alertă activă în următoarele 90 zile!' : 'Nicio alertă cu filtrele aplicate.'}
        </div>
      ) : (
        <div style={{...S.card, overflow:'hidden'}}>
          <div style={{maxHeight:600, overflow:'auto'}}>
            <table style={{width:'100%', borderCollapse:'collapse', fontSize:13}}>
              <thead style={{position:'sticky', top:0, background:G.surface, zIndex:1}}>
                <tr style={{borderBottom:`2px solid ${G.border2}`}}>
                  <th style={{padding:'10px 12px', textAlign:'left', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase'}}>Sursă</th>
                  <th style={{padding:'10px 12px', textAlign:'left', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase'}}>Țintă</th>
                  <th style={{padding:'10px 12px', textAlign:'left', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase'}}>Tip document</th>
                  <th style={{padding:'10px 12px', textAlign:'left', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase'}}>Număr</th>
                  <th style={{padding:'10px 12px', textAlign:'left', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase'}}>Expiră</th>
                  <th style={{padding:'10px 12px', textAlign:'center', fontSize:11, color:G.muted, fontWeight:700, textTransform:'uppercase'}}>Status</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((m, i) => (
                  <tr key={m.id} style={{borderBottom:`1px solid ${G.border}`, background: i%2===0 ? 'transparent' : G.bg+'77'}}>
                    <td style={{padding:'9px 12px'}}>
                      <span style={{fontSize:11, padding:'2px 8px', borderRadius:4, fontWeight:700,
                        background: m.sursa==='Flotă' ? G.logistica+'22' : G.purple+'22',
                        color: m.sursa==='Flotă' ? G.logistica : G.purple,
                      }}>{m.sursa==='Flotă' ? '🚛 Flotă' : '👤 HR'}</span>
                    </td>
                    <td style={{padding:'9px 12px'}}>
                      <div style={{fontFamily: m.sursa==='Flotă' ? 'monospace' : 'inherit', fontWeight:700, color: m.sursa==='Flotă' ? G.blue : G.text}}>{m.target}</div>
                      {m.target_desc && <div style={{fontSize:11, color:G.muted}}>{m.target_desc}</div>}
                    </td>
                    <td style={{padding:'9px 12px', fontWeight:600}}>{m.tip}</td>
                    <td style={{padding:'9px 12px', fontFamily:'monospace', fontSize:12, color:G.muted}}>{m.numar || '—'}</td>
                    <td style={{padding:'9px 12px', fontWeight:600}}>{fmtDate(m.data_expirare)}</td>
                    <td style={{padding:'9px 12px', textAlign:'center'}}><DocStatusBadge zile={m.zile} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div style={{padding:'8px 14px', borderTop:`1px solid ${G.border}`, fontSize:11, color:G.muted, background:G.bg}}>
            {filtered.length} din {merged.length} alerte (90 zile)
          </div>
        </div>
      )}
    </>
  )
}

// ─── Placeholder pentru tab-uri în curs de dezvoltare ────────────────────────
function PlaceholderTab({ label, desc, emoji }) {
  return (
    <div style={{...S.card, padding: 60, textAlign: 'center'}}>
      <div style={{fontSize: 64, marginBottom: 14, opacity: .4}}>{emoji}</div>
      <div style={{fontSize: 22, fontWeight: 800, color: G.text, marginBottom: 6}}>{label}</div>
      <div style={{fontSize: 13, color: G.muted, marginBottom: 18}}>{desc}</div>
      <div style={{display: 'inline-block', padding: '6px 14px', background: G.yellow + '22', color: G.yellow, fontSize: 11, fontWeight: 700, borderRadius: 14, letterSpacing: '.5px'}}>
        🚧 ÎN DEZVOLTARE
      </div>
    </div>
  )
}

// ─── Pagina Alimentări — input bulk per zi ──────────────────────────────────
// ─── Modal Editare Alimentare existentă ─────────────────────────────────────
function EditAlimentareModal({ alim, sites, rezervorGazpet, pretMotorina, onClose, onSaved, showToast }) {
  const [form, setForm] = useState({
    data_alimentare: alim.data_alimentare,
    cantitate_litri: alim.cantitate_litri || '',
    ore_la_alimentare: alim.ore_la_alimentare || '',
    km_la_alimentare: alim.km_la_alimentare || '',
    ore_lucrate_efectiv: alim.ore_lucrate_efectiv || '',
    statie_combustibil: alim.statie_combustibil || '',
    site_id: alim.site_id ? String(alim.site_id) : '',
    pret_total: alim.pret_total || '',
    pret_per_litru: alim.pret_per_litru || '',
    card_combustibil: alim.card_combustibil || '',
    numar_factura: alim.numar_factura || '',
    observatii: alim.observatii || '',
  })
  const [saving, setSaving] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const setField = (k, v) => setForm(p => ({ ...p, [k]: v }))
  const isGazpet = form.statie_combustibil === STATIE_GAZPET
  
  const handleTotalChange = (v) => {
    setField('pret_total', v)
    if (v && form.cantitate_litri && Number(form.cantitate_litri) > 0) {
      setField('pret_per_litru', (Number(v) / Number(form.cantitate_litri)).toFixed(4))
    }
  }
  const handlePretLChange = (v) => {
    setField('pret_per_litru', v)
    if (v && form.cantitate_litri && Number(form.cantitate_litri) > 0) {
      setField('pret_total', (Number(v) * Number(form.cantitate_litri)).toFixed(2))
    }
  }
  
  const pretLNum = Number(form.pret_per_litru) || 0
  const isPretSuspect = form.pret_per_litru && (pretLNum < 1 || pretLNum > 20)
  
  const activMeta = alim.logistica_active || {}
  
  const handleSave = async () => {
    if (!form.cantitate_litri || Number(form.cantitate_litri) <= 0) { showToast('Cantitatea trebuie > 0', 'error'); return }
    if (isPretSuspect) {
      const ok = window.confirm(`⚠️ Preț/L atipic: ${form.pret_per_litru} RON/L\nContinui oricum?`)
      if (!ok) return
    }
    
    setSaving(true)
    const payload = {
      data_alimentare: form.data_alimentare,
      cantitate_litri: Number(form.cantitate_litri),
      ore_la_alimentare: form.ore_la_alimentare ? Number(form.ore_la_alimentare) : null,
      km_la_alimentare: form.km_la_alimentare ? Number(form.km_la_alimentare) : null,
      ore_lucrate_efectiv: form.ore_lucrate_efectiv ? Number(form.ore_lucrate_efectiv) : null,
      statie_combustibil: form.statie_combustibil || null,
      site_id: form.site_id ? Number(form.site_id) : null,
      pret_total: form.pret_total ? Number(form.pret_total) : null,
      pret_per_litru: form.pret_per_litru ? Number(form.pret_per_litru) : null,
      card_combustibil: form.card_combustibil.trim() || null,
      numar_factura: form.numar_factura.trim() || null,
      observatii: form.observatii.trim() || null,
      rezervor_id: isGazpet && rezervorGazpet ? rezervorGazpet.id : null,
    }
    
    const { error } = await supabase.from('logistica_alimentari').update(payload).eq('id', alim.id)
    setSaving(false)
    if (error) { showToast(`Eroare: ${error.message}`, 'error'); return }
    showToast(`✓ Alimentare modificată`, 'success')
    onSaved()
  }
  
  const handleDelete = async () => {
    if (!window.confirm(`Ștergi alimentarea de ${alim.cantitate_litri} L de pe ${fmtDate(alim.data_alimentare)}?\n\nStocul rezervorului va fi ajustat automat.`)) return
    setDeleting(true)
    const { error } = await supabase.from('logistica_alimentari').delete().eq('id', alim.id)
    setDeleting(false)
    if (error) { showToast(`Eroare: ${error.message}`, 'error'); return }
    showToast(`✓ Alimentare ștearsă`, 'success')
    onSaved()
  }
  
  return (
    <div onClick={onClose} style={{position:'fixed', inset:0, background:'#000000cc', zIndex:300, display:'flex', alignItems:'flex-start', justifyContent:'center', padding:'40px 16px', overflowY:'auto'}}>
      <div onClick={e => e.stopPropagation()} style={{...S.card, padding: 22, width: '100%', maxWidth: 620, boxShadow: '0 20px 80px rgba(0,0,0,.6)', borderTop: `3px solid ${G.logistica}`}} className="fi">
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom: 16, paddingBottom: 14, borderBottom: `1px solid ${G.border}`}}>
          <div>
            <div style={{fontSize: 18, fontWeight: 800, color: G.text, marginBottom: 4}}>
              ✏️ Editare alimentare #{alim.id}
            </div>
            <div style={{fontSize: 12, color: G.muted}}>
              {activMeta.marca} {activMeta.model} · {activMeta.cod_intern || activMeta.nr_inmatriculare}
            </div>
          </div>
          <button onClick={onClose} style={{background:'transparent', border:'none', color:G.muted, fontSize: 22, cursor:'pointer', padding: 4}}>×</button>
        </div>
        
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12, marginBottom: 12}}>
          <FieldText label="Data" value={form.data_alimentare} onChange={v => setField('data_alimentare', v)} type="date" />
          <FieldText label="Cantitate (litri)" value={form.cantitate_litri} onChange={v => setField('cantitate_litri', v)} type="number" />
        </div>
        
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12, marginBottom: 12}}>
          <FieldSelect label="Stație" value={form.statie_combustibil} onChange={v => setField('statie_combustibil', v)} options={STATII} placeholder="—" />
          <FieldSelect label="Șantier" value={form.site_id} onChange={v => setField('site_id', v)} options={[{label:'— niciun șantier —', value:''}, ...(sites||[]).map(s => ({label: s.name, value: String(s.id)}))]} placeholder="—" />
        </div>
        
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap: 12, marginBottom: 12}}>
          <FieldText label="Ore bord" value={form.ore_la_alimentare} onChange={v => setField('ore_la_alimentare', v)} type="number" />
          <FieldText label="Km" value={form.km_la_alimentare} onChange={v => setField('km_la_alimentare', v)} type="number" />
          <FieldText label="Ore lucrate" value={form.ore_lucrate_efectiv} onChange={v => setField('ore_lucrate_efectiv', v)} type="number" />
        </div>
        
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12, marginBottom: 8}}>
          <FieldText label="Preț/litru (RON/L)" value={form.pret_per_litru} onChange={handlePretLChange} type="number" placeholder="ex: 7.50" />
          <FieldText label="Cost total (RON)" value={form.pret_total} onChange={handleTotalChange} type="number" placeholder="ex: 380.50" />
        </div>
        
        {isPretSuspect && (
          <div style={{padding: 8, background: G.redDim + '88', border: `1px solid ${G.red}55`, borderRadius: 6, marginBottom: 12, fontSize: 11, color: G.red}}>
            ⚠️ Preț/litru atipic: {form.pret_per_litru} RON/L. Pentru motorină: 6-9 RON/L.
          </div>
        )}
        
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12, marginBottom: 12}}>
          <FieldText label="Card combustibil" value={form.card_combustibil} onChange={v => setField('card_combustibil', v)} placeholder="ex: 7059-XXXX" />
          <FieldText label="Număr factură" value={form.numar_factura} onChange={v => setField('numar_factura', v)} placeholder="F-2026-..." />
        </div>
        
        <div style={{marginBottom: 14}}>
          <FieldTextarea label="Observații" value={form.observatii} onChange={v => setField('observatii', v)} rows={2} />
        </div>
        
        <div style={{display:'flex', justifyContent:'space-between', gap: 8, paddingTop: 14, borderTop: `1px solid ${G.border}`}}>
          <button onClick={handleDelete} disabled={deleting || saving} style={{...S.btnS, fontSize: 12, color: G.red, borderColor: G.red + '55', opacity: (deleting || saving) ? .5 : 1}}>
            {deleting ? '⏳' : '🗑️ Șterge'}
          </button>
          <div style={{display:'flex', gap: 8}}>
            <button onClick={onClose} style={{...S.btnS, fontSize: 13, color: G.muted}} disabled={saving || deleting}>Anulează</button>
            <button onClick={handleSave} disabled={saving || deleting} style={{...S.btnP, background: G.logistica, color: '#000', opacity: (saving || deleting) ? .6 : 1}}>
              {saving ? '⏳' : '✓ Salvează modificările'}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

function AlimentariBulkPage({ active, ultimeAlim, sites, rezervorGazpet, pretMotorina, dataAlim, setDataAlim, canEdit, showToast, onSaved }) {
  const [filterText, setFilterText] = useState('')
  const [filterTip, setFilterTip] = useState('Toate')
  const [filterSub, setFilterSub] = useState('Toate')
  const [forms, setForms] = useState({})
  const [savingId, setSavingId] = useState(null)
  const [saved, setSaved] = useState({})
  const [pretMediuGazpet, setPretMediuGazpet] = useState(null)
  
  // State pentru listă alimentări înregistrate (cu filtru perioadă + edit)
  const [perioadaF, setPerioadaF] = useState('azi')  // 'azi' | 'ieri' | 'saptamana' | 'luna' | 'custom'
  const [customStart, setCustomStart] = useState('')
  const [customEnd, setCustomEnd] = useState('')
  const [alimList, setAlimList] = useState([])
  const [loadingAlim, setLoadingAlim] = useState(false)
  const [editAlim, setEditAlim] = useState(null)
  
  // Calculez preț mediu Gazpet
  useEffect(() => {
    if (!rezervorGazpet?.id) return
    supabase.from('logistica_achizitii_vrac')
      .select('cantitate_litri, pret_per_litru')
      .eq('rezervor_id', rezervorGazpet.id)
      .not('pret_per_litru', 'is', null)
      .then(({ data }) => {
        if (!data?.length) return
        const totalLitri = data.reduce((s, a) => s + Number(a.cantitate_litri || 0), 0)
        const totalCost = data.reduce((s, a) => s + Number(a.cantitate_litri || 0) * Number(a.pret_per_litru || 0), 0)
        if (totalLitri > 0) setPretMediuGazpet((totalCost / totalLitri).toFixed(4))
      })
  }, [rezervorGazpet?.id])
  
  // Filtru: doar active cu combustibil + tip + subcategorie + text
  const activeFiltrate = useMemo(() => {
    let res = active.filter(a => a.tip_carburant && a.tip_carburant.trim() !== '')
    if (filterTip !== 'Toate') res = res.filter(a => a.logistica_categorii?.tip === filterTip)
    if (filterSub !== 'Toate') res = res.filter(a => a.logistica_categorii?.subcategorie === filterSub)
    if (filterText.trim()) {
      const q = filterText.toLowerCase()
      res = res.filter(a => 
        (a.cod_intern || '').toLowerCase().includes(q) ||
        (a.nr_inmatriculare || '').toLowerCase().includes(q) ||
        (a.marca || '').toLowerCase().includes(q) ||
        (a.model || '').toLowerCase().includes(q)
      )
    }
    return res
  }, [active, filterText, filterTip, filterSub])
  
  // Tipuri și subcategorii unice (din active filtrate cu combustibil)
  const tipuri = useMemo(() => {
    const set = new Set()
    active.filter(a => a.tip_carburant).forEach(a => { if (a.logistica_categorii?.tip) set.add(a.logistica_categorii.tip) })
    return Array.from(set).sort()
  }, [active])
  
  const subcategorii = useMemo(() => {
    const set = new Set()
    active.filter(a => a.tip_carburant && (filterTip === 'Toate' || a.logistica_categorii?.tip === filterTip))
      .forEach(a => { if (a.logistica_categorii?.subcategorie) set.add(a.logistica_categorii.subcategorie) })
    return Array.from(set).sort()
  }, [active, filterTip])
  
  // Calc dată pentru filtru perioadă
  const calcPerioada = () => {
    const today = new Date().toISOString().split('T')[0]
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0]
    const week = new Date(Date.now() - 7*86400000).toISOString().split('T')[0]
    const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0]
    
    if (perioadaF === 'azi') return { start: today, end: today, label: 'Azi' }
    if (perioadaF === 'ieri') return { start: yesterday, end: yesterday, label: 'Ieri' }
    if (perioadaF === 'saptamana') return { start: week, end: today, label: 'Ultimele 7 zile' }
    if (perioadaF === 'luna') return { start: monthStart, end: today, label: 'Luna curentă' }
    if (perioadaF === 'custom' && customStart && customEnd) return { start: customStart, end: customEnd, label: `${fmtDate(customStart)} → ${fmtDate(customEnd)}` }
    return null
  }
  
  // Fetch alimentări pentru perioada selectată
  const fetchAlimentari = async () => {
    const p = calcPerioada()
    if (!p) { setAlimList([]); return }
    setLoadingAlim(true)
    const { data } = await supabase.from('logistica_alimentari')
      .select(`*, logistica_active(cod_intern, nr_inmatriculare, marca, model, tip_carburant), sites(name), profiles!created_by(name)`)
      .gte('data_alimentare', p.start)
      .lte('data_alimentare', p.end)
      .order('data_alimentare', { ascending: false })
      .order('id', { ascending: false })
    setAlimList(data || [])
    setLoadingAlim(false)
  }
  
  useEffect(() => { fetchAlimentari() }, [perioadaF, customStart, customEnd])
  
  const setFormField = (activId, field, value) => {
    setForms(prev => ({ ...prev, [activId]: { ...prev[activId], [field]: value } }))
  }
  
  const getForm = (activId) => forms[activId] || {}
  
  const navigateDate = (delta) => {
    const d = new Date(dataAlim)
    d.setDate(d.getDate() + delta)
    setDataAlim(d.toISOString().split('T')[0])
  }
  
  const handleSave = async (activ) => {
    const f = getForm(activ.id)
    if (!f.cantitate_litri || Number(f.cantitate_litri) <= 0) { showToast(`Cantitatea trebuie > 0 pentru ${activ.cod_intern || activ.nr_inmatriculare}`, 'error'); return }
    
    const isGazpet = f.statie_combustibil === STATIE_GAZPET
    const pretBaza = isGazpet ? (pretMediuGazpet || pretMotorina) : pretMotorina
    const pretL = f.pret_per_litru ? Number(f.pret_per_litru) : (pretBaza ? Number(pretBaza) : null)
    const pretTotal = pretL ? Number((Number(f.cantitate_litri) * pretL).toFixed(2)) : null
    
    // Warning preț atipic
    if (pretL && (pretL < 1 || pretL > 20)) {
      const ok = window.confirm(`⚠️ Preț/litru atipic: ${pretL} RON/L pentru ${activ.cod_intern || activ.nr_inmatriculare}\n\nContinui oricum?`)
      if (!ok) return
    }
    
    setSavingId(activ.id)
    const { data: { user } } = await supabase.auth.getUser()
    
    // Calc ore lucrate efectiv = ore_la_alimentare - ore_precedente (dacă e disponibil)
    const orePrec = ultimeAlim[activ.id]?.ultime_ore
    const oreLaAlim = f.ore_la_alimentare ? Number(f.ore_la_alimentare) : null
    const oreLucrate = (orePrec && oreLaAlim && oreLaAlim > Number(orePrec)) ? oreLaAlim - Number(orePrec) : null
    
    const payload = {
      active_id: activ.id,
      data_alimentare: dataAlim,
      cantitate_litri: Number(f.cantitate_litri),
      ore_la_alimentare: oreLaAlim,
      km_la_alimentare: f.km_la_alimentare ? Number(f.km_la_alimentare) : null,
      ore_lucrate_efectiv: oreLucrate,
      statie_combustibil: f.statie_combustibil || null,
      pret_total: pretTotal,
      pret_per_litru: pretL,
      rezervor_id: isGazpet && rezervorGazpet ? rezervorGazpet.id : null,
      site_id: f.site_id ? Number(f.site_id) : null,
      created_by: user?.id,
    }
    
    const { error } = await supabase.from('logistica_alimentari').insert(payload)
    setSavingId(null)
    
    if (error) { showToast(`Eroare: ${error.message}`, 'error'); return }
    
    showToast(`✓ ${activ.cod_intern || activ.nr_inmatriculare}: ${f.cantitate_litri} L`, 'success')
    setSaved(prev => ({ ...prev, [activ.id]: true }))
    setForms(prev => ({ ...prev, [activ.id]: {} }))  // resetez form
    fetchAlimentari()  // refresh listă alimentări
    onSaved()
  }
  
  return (
    <div>
      {/* Header navigare dată + filtre */}
      <div style={{...S.card, padding: '14px 18px', marginBottom: 14}}>
        <div style={{fontSize: 11, color: G.orange, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.6px', marginBottom: 10}}>
          📥 Înregistrare alimentări
        </div>
        <div style={{display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap', marginBottom: 10}}>
          <div style={{display: 'flex', alignItems: 'center', gap: 8}}>
            <button onClick={() => navigateDate(-1)} style={{...S.btnS, padding: '6px 10px', fontSize: 16}} title="Ziua precedentă">◀</button>
            <input type="date" value={dataAlim} onChange={e => setDataAlim(e.target.value)} style={{...S.input, padding: '6px 10px', fontSize: 14, fontWeight: 700, color: G.text, minWidth: 150}} />
            <button onClick={() => navigateDate(1)} style={{...S.btnS, padding: '6px 10px', fontSize: 16}} title="Ziua următoare">▶</button>
            <button onClick={() => setDataAlim(new Date().toISOString().split('T')[0])} style={{...S.btnS, padding: '6px 12px', fontSize: 12, color: G.logistica, borderColor: G.logistica + '55'}}>Azi</button>
            <button onClick={() => { const d = new Date(); d.setDate(d.getDate() - 1); setDataAlim(d.toISOString().split('T')[0]) }} style={{...S.btnS, padding: '6px 12px', fontSize: 12, color: G.muted}}>Ieri</button>
          </div>
        </div>
        
        {/* Filtre Tip + Subcategorie + Text */}
        <div style={{display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center'}}>
          <div style={{fontSize: 11, color: G.muted, fontWeight: 600}}>FILTRU:</div>
          <select value={filterTip} onChange={e => { setFilterTip(e.target.value); setFilterSub('Toate') }} style={{...S.input, padding: '6px 10px', fontSize: 12, minWidth: 140}}>
            <option value="Toate">Toate tipurile</option>
            {tipuri.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
          <select value={filterSub} onChange={e => setFilterSub(e.target.value)} disabled={filterTip === 'Toate'} style={{...S.input, padding: '6px 10px', fontSize: 12, minWidth: 160, opacity: filterTip === 'Toate' ? .5 : 1}}>
            <option value="Toate">Toate subcategoriile</option>
            {subcategorii.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
          <input type="text" placeholder="🔍 marcă, cod, plăcuță..." value={filterText} onChange={e => setFilterText(e.target.value)} style={{...S.input, padding: '6px 12px', fontSize: 12, minWidth: 200, flex: 1}} />
          {(filterTip !== 'Toate' || filterSub !== 'Toate' || filterText) && (
            <button onClick={() => { setFilterTip('Toate'); setFilterSub('Toate'); setFilterText('') }} style={{...S.btnS, padding: '6px 10px', fontSize: 11, color: G.muted}}>×  Resetează</button>
          )}
        </div>
      </div>
      
      {/* Info banner */}
      <div style={{padding: 10, marginBottom: 14, background: G.bg, border: `1px solid ${G.border}`, borderRadius: 8, fontSize: 12, color: G.muted}}>
        💡 <strong style={{color: G.text}}>{activeFiltrate.length}</strong> utilaje afișate. Completezi doar rândurile relevante și apasă <strong style={{color: G.green}}>✓ Save</strong> pe fiecare. Datele se salvează cu data <strong style={{color: G.text}}>{fmtDate(dataAlim)}</strong>.
      </div>
      
      {/* Listă active cu form inline */}
      <div style={{display: 'flex', flexDirection: 'column', gap: 8}}>
        {activeFiltrate.length === 0 ? (
          <div style={{...S.card, padding: 30, textAlign: 'center', color: G.muted}}>
            Niciun activ corespunzător filtrelor.
          </div>
        ) : activeFiltrate.map(activ => {
          const f = getForm(activ.id)
          const ultima = ultimeAlim[activ.id]
          const isGazpet = f.statie_combustibil === STATIE_GAZPET
          const isSaved = saved[activ.id]
          
          return (
            <div key={activ.id} style={{
              ...S.card,
              padding: '10px 14px',
              borderLeft: `3px solid ${isSaved ? G.green : (f.cantitate_litri ? G.orange : G.border)}`,
              opacity: isSaved ? .7 : 1,
            }}>
              {/* Rând 1: Identificare + status */}
              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8, flexWrap: 'wrap', gap: 8}}>
                <div style={{flex: 1, minWidth: 200}}>
                  <div style={{fontSize: 13, fontWeight: 700, color: G.text}}>
                    {activ.marca} {activ.model}
                  </div>
                  <div style={{fontSize: 11, color: G.muted, marginTop: 2}}>
                    {activ.cod_intern && <span style={{color: G.logistica, fontFamily: 'monospace'}}>{activ.cod_intern}</span>}
                    {activ.nr_inmatriculare && <span style={{color: G.blue, fontFamily: 'monospace', marginLeft: activ.cod_intern ? 8 : 0}}>{activ.nr_inmatriculare}</span>}
                    {activ.tip_carburant && <span style={{marginLeft: 8}}>· {activ.tip_carburant}</span>}
                    {activ.norma_consum && <span style={{marginLeft: 4}}>· {activ.norma_consum} {activ.unitate_norma || 'l/h'}</span>}
                  </div>
                  {ultima && (
                    <div style={{fontSize: 10, color: G.muted, marginTop: 2}}>
                      Ultima alim: {fmtDate(ultima.ultima_data)}
                      {ultima.ultime_litri && ` · ${Number(ultima.ultime_litri).toFixed(1)}L`}
                      {ultima.ultime_ore && ` · ${ultima.ultime_ore} ore bord`}
                      {ultima.ultimi_km && ` · ${Number(ultima.ultimi_km).toLocaleString('ro-RO')} km`}
                    </div>
                  )}
                </div>
                {isSaved && (
                  <span style={{fontSize: 11, padding: '3px 8px', background: G.green + '22', color: G.green, borderRadius: 4, fontWeight: 700}}>
                    ✓ SALVAT
                  </span>
                )}
              </div>
              
              {/* Rând 2: Form inline */}
              {!isSaved && (
                <div style={{display: 'grid', gridTemplateColumns: '90px 130px 130px 80px 80px 80px', gap: 6, alignItems: 'end'}}>
                  <FieldText label="Cant. (L)" value={f.cantitate_litri || ''} onChange={v => setFormField(activ.id, 'cantitate_litri', v)} type="number" placeholder="50" />
                  <FieldSelect label="Sursa" value={f.statie_combustibil || ''} onChange={v => setFormField(activ.id, 'statie_combustibil', v)} options={STATII} placeholder="—" />
                  <FieldSelect label="Șantier" value={f.site_id || ''} onChange={v => setFormField(activ.id, 'site_id', v)} options={[{label:'—', value:''}, ...(sites||[]).map(s => ({label: s.name, value: String(s.id)}))]} placeholder="—" />
                  <FieldText label={ultima?.ultime_ore ? `Ore (de la ${ultima.ultime_ore})` : "Ore bord"} value={f.ore_la_alimentare || ''} onChange={v => setFormField(activ.id, 'ore_la_alimentare', v)} type="number" placeholder={ultima?.ultime_ore ? String(Number(ultima.ultime_ore) + 8) : "ex: 1248"} />
                  <FieldText label="Km" value={f.km_la_alimentare || ''} onChange={v => setFormField(activ.id, 'km_la_alimentare', v)} type="number" placeholder={ultima?.ultimi_km ? String(ultima.ultimi_km) : ""} />
                  <button 
                    onClick={() => handleSave(activ)} 
                    disabled={savingId === activ.id || !canEdit || !f.cantitate_litri}
                    style={{...S.btnP, background: G.green, padding: '7px 12px', fontSize: 12, opacity: (savingId === activ.id || !canEdit || !f.cantitate_litri) ? .4 : 1, cursor: (savingId === activ.id || !canEdit || !f.cantitate_litri) ? 'not-allowed' : 'pointer'}}>
                    {savingId === activ.id ? '⏳' : '✓ Save'}
                  </button>
                </div>
              )}
              
              {/* Banner Gazpet în mini-form */}
              {!isSaved && isGazpet && rezervorGazpet && f.cantitate_litri && (
                <div style={{marginTop: 6, padding: '5px 10px', background: G.purple + '15', border: `1px solid ${G.purple}33`, borderRadius: 6, fontSize: 10, color: G.muted}}>
                  📦 Stoc Gazpet: {Number(rezervorGazpet.stoc_curent_litri).toFixed(0)}L → {(Number(rezervorGazpet.stoc_curent_litri) - Number(f.cantitate_litri)).toFixed(0)}L
                  {pretMediuGazpet && <> · preț mediu vrac: <strong style={{color: G.text}}>{pretMediuGazpet} RON/L</strong></>}
                </div>
              )}
            </div>
          )
        })}
      </div>
      
      {Object.keys(saved).length > 0 && (
        <div style={{marginTop: 14, padding: 10, background: G.greenDim + '88', border: `1px solid ${G.green}55`, borderRadius: 8, fontSize: 12, color: G.text, textAlign: 'center'}}>
          ✓ <strong style={{color: G.green}}>{Object.keys(saved).length} alimentări înregistrate</strong> pentru {fmtDate(dataAlim)}
        </div>
      )}
      
      {/* ──────────────────────────────────────────────────────────────────── */}
      {/* SECȚIUNEA 2: Alimentări înregistrate (vizualizare + edit + ștergere) */}
      {/* ──────────────────────────────────────────────────────────────────── */}
      <div style={{marginTop: 24}}>
        <div style={{...S.card, padding: '14px 18px', marginBottom: 12}}>
          <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10, flexWrap: 'wrap', gap: 8}}>
            <div style={{fontSize: 11, color: G.purple, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.6px'}}>
              📋 Alimentări înregistrate {alimList.length > 0 && <span style={{color: G.muted, fontWeight: 500}}>({alimList.length})</span>}
            </div>
            {alimList.length > 0 && (
              <div style={{fontSize: 12, color: G.muted}}>
                Total: <strong style={{color: G.text}}>{alimList.reduce((s,a) => s + Number(a.cantitate_litri || 0), 0).toFixed(1)} L</strong>
                {alimList.some(a => a.pret_total) && <> · <strong style={{color: G.green}}>{alimList.reduce((s,a) => s + Number(a.pret_total || 0), 0).toLocaleString('ro-RO', {minimumFractionDigits: 2, maximumFractionDigits: 2})} RON</strong></>}
              </div>
            )}
          </div>
          
          {/* Filtru perioadă */}
          <div style={{display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap'}}>
            <span style={{fontSize: 11, color: G.muted, fontWeight: 600, marginRight: 4}}>PERIOADĂ:</span>
            {[
              {key: 'azi', label: 'Azi'},
              {key: 'ieri', label: 'Ieri'},
              {key: 'saptamana', label: '7 zile'},
              {key: 'luna', label: 'Luna'},
              {key: 'custom', label: 'Custom'},
            ].map(p => (
              <button key={p.key} onClick={() => setPerioadaF(p.key)} style={{
                ...S.btnS, padding: '6px 12px', fontSize: 12, fontWeight: 600,
                background: perioadaF === p.key ? G.purple + '22' : 'transparent',
                color: perioadaF === p.key ? G.purple : G.muted,
                borderColor: perioadaF === p.key ? G.purple + '55' : G.border,
              }}>{p.label}</button>
            ))}
            {perioadaF === 'custom' && (
              <>
                <input type="date" value={customStart} onChange={e => setCustomStart(e.target.value)} style={{...S.input, padding: '6px 10px', fontSize: 12, minWidth: 140}} />
                <span style={{color: G.muted, fontSize: 12}}>→</span>
                <input type="date" value={customEnd} onChange={e => setCustomEnd(e.target.value)} style={{...S.input, padding: '6px 10px', fontSize: 12, minWidth: 140}} />
              </>
            )}
          </div>
        </div>
        
        {/* Tabel alimentări */}
        {loadingAlim ? (
          <div style={{...S.card, padding: 30, textAlign: 'center', color: G.muted, fontSize: 13}}>⏳ Se încarcă...</div>
        ) : alimList.length === 0 ? (
          <div style={{...S.card, padding: 30, textAlign: 'center', color: G.muted, fontSize: 13}}>
            Nicio alimentare înregistrată în această perioadă.
          </div>
        ) : (
          <div style={{...S.card, padding: 0, overflow: 'hidden'}}>
            <div style={{overflowX: 'auto'}}>
              <table style={{width: '100%', borderCollapse: 'collapse', fontSize: 12}}>
                <thead>
                  <tr style={{background: G.surface, borderBottom: `2px solid ${G.border}`}}>
                    <th style={{padding: '10px 12px', textAlign: 'left', color: G.muted, fontWeight: 700, fontSize: 11, textTransform: 'uppercase', letterSpacing: '.4px'}}>Data</th>
                    <th style={{padding: '10px 12px', textAlign: 'left', color: G.muted, fontWeight: 700, fontSize: 11, textTransform: 'uppercase', letterSpacing: '.4px'}}>Utilaj</th>
                    <th style={{padding: '10px 12px', textAlign: 'right', color: G.muted, fontWeight: 700, fontSize: 11, textTransform: 'uppercase', letterSpacing: '.4px'}}>Cantitate</th>
                    <th style={{padding: '10px 12px', textAlign: 'left', color: G.muted, fontWeight: 700, fontSize: 11, textTransform: 'uppercase', letterSpacing: '.4px'}}>Sursa</th>
                    <th style={{padding: '10px 12px', textAlign: 'left', color: G.muted, fontWeight: 700, fontSize: 11, textTransform: 'uppercase', letterSpacing: '.4px'}}>Șantier</th>
                    <th style={{padding: '10px 12px', textAlign: 'right', color: G.muted, fontWeight: 700, fontSize: 11, textTransform: 'uppercase', letterSpacing: '.4px'}}>Ore bord</th>
                    <th style={{padding: '10px 12px', textAlign: 'right', color: G.muted, fontWeight: 700, fontSize: 11, textTransform: 'uppercase', letterSpacing: '.4px'}}>Cost</th>
                    <th style={{padding: '10px 12px', textAlign: 'left', color: G.muted, fontWeight: 700, fontSize: 11, textTransform: 'uppercase', letterSpacing: '.4px'}}>Cine</th>
                    <th style={{padding: '10px 12px', textAlign: 'center', color: G.muted, fontWeight: 700, fontSize: 11, textTransform: 'uppercase', letterSpacing: '.4px', width: 80}}></th>
                  </tr>
                </thead>
                <tbody>
                  {alimList.map(a => {
                    const av = a.logistica_active || {}
                    const pretL = Number(a.pret_per_litru || 0)
                    const isPretSusp = a.pret_per_litru && (pretL < 1 || pretL > 20)
                    return (
                      <tr key={a.id} style={{borderBottom: `1px solid ${G.border}`}}>
                        <td style={{padding: '8px 12px', fontFamily: 'monospace', color: G.text, fontWeight: 600}}>{fmtDate(a.data_alimentare)}</td>
                        <td style={{padding: '8px 12px'}}>
                          <div style={{fontWeight: 600, color: G.text}}>{av.marca} {av.model?.substring(0, 30)}{av.model?.length > 30 ? '...' : ''}</div>
                          <div style={{fontSize: 10, color: G.muted, marginTop: 2}}>
                            {av.cod_intern && <span style={{color: G.logistica, fontFamily: 'monospace'}}>{av.cod_intern}</span>}
                            {av.nr_inmatriculare && <span style={{color: G.blue, fontFamily: 'monospace', marginLeft: 6}}>{av.nr_inmatriculare}</span>}
                          </div>
                        </td>
                        <td style={{padding: '8px 12px', textAlign: 'right', color: G.orange, fontWeight: 700, fontVariantNumeric: 'tabular-nums'}}>
                          {Number(a.cantitate_litri).toFixed(1)} L
                        </td>
                        <td style={{padding: '8px 12px', fontSize: 11, color: a.statie_combustibil === STATIE_GAZPET ? G.purple : G.text}}>
                          {a.statie_combustibil || '—'}
                        </td>
                        <td style={{padding: '8px 12px', fontSize: 11, color: G.text}}>
                          {a.sites?.name || <span style={{color: G.muted}}>—</span>}
                        </td>
                        <td style={{padding: '8px 12px', textAlign: 'right', fontFamily: 'monospace', color: G.muted}}>
                          {a.ore_la_alimentare || '—'}
                        </td>
                        <td style={{padding: '8px 12px', textAlign: 'right', fontVariantNumeric: 'tabular-nums'}}>
                          {a.pret_total ? (
                            <div>
                              <div style={{color: isPretSusp ? G.red : G.green, fontWeight: 700}}>
                                {Number(a.pret_total).toFixed(2)} RON
                              </div>
                              {isPretSusp && <div style={{fontSize: 9, color: G.red, fontWeight: 600}}>⚠️ {pretL} /L</div>}
                            </div>
                          ) : <span style={{color: G.muted}}>—</span>}
                        </td>
                        <td style={{padding: '8px 12px', fontSize: 10, color: G.muted}}>
                          {a.profiles?.name?.split(' ')[0] || '—'}
                        </td>
                        <td style={{padding: '8px 12px', textAlign: 'center'}}>
                          {canEdit && (
                            <button onClick={() => setEditAlim(a)} style={{...S.btnS, padding: '4px 8px', fontSize: 11, color: G.logistica, borderColor: G.logistica + '55'}} title="Editează / Șterge">
                              ✏️
                            </button>
                          )}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
      
      {/* Modal edit alimentare */}
      {editAlim && (
        <EditAlimentareModal 
          alim={editAlim}
          sites={sites}
          rezervorGazpet={rezervorGazpet}
          pretMotorina={pretMotorina}
          onClose={() => setEditAlim(null)}
          onSaved={() => { setEditAlim(null); fetchAlimentari(); onSaved() }}
          showToast={showToast}
        />
      )}
    </div>
  )
}


export default function LogisticaPage() {
  const nav = useNavigate()
  const [profile, setProfile] = useState(null)
  const [accessLevel, setAccessLevel] = useState(undefined)
  const [active, setActive] = useState([])
  const [categorii, setCategorii] = useState([])
  const [kpi, setKpi] = useState(null)
  const [kpiAlim, setKpiAlim] = useState(null)
  const [load, setLoad] = useState(true)
  const [search, setSearch] = useState('')
  const [tipF, setTipF] = useState('Toate')
  const [subF, setSubF] = useState('Toate')
  const [stareF, setStareF] = useState('Toate')
  const [sortBy, setSortBy] = useState({ col: 'marca', dir: 'asc' })  // sortare tabel
  const [modal, setModal] = useState(null)
  const [rezervor, setRezervor] = useState(null)         // rezervorul Gazpet Oscar
  const [sites, setSites] = useState([])                  // pentru alocare alimentare pe șantier
  const [pretMotorina, setPretMotorina] = useState(null) // preț curent
  const [pretMotorinaActualizat, setPretMotorinaActualizat] = useState(null)
  const [showAchizitie, setShowAchizitie] = useState(false)
  const [showEditStoc, setShowEditStoc] = useState(false)
  const [showSetariPret, setShowSetariPret] = useState(false)
  const [tab, setTab] = useState('lista')                    // 'lista' | 'alimentari' | 'documente' | 'service' | 'tichete'
  const [dataAlim, setDataAlim] = useState(new Date().toISOString().split('T')[0]) // pt tab Alimentări
  const [ultimeAlim, setUltimeAlim] = useState({})           // map active_id → ultima alimentare
  const [toast, showToast] = useToast()
  
  useEffect(() => {
    const init = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { setAccessLevel(null); return }
      const [{ data: prof }, { data: access }] = await Promise.all([
        supabase.from('profiles').select('*').eq('id', user.id).single(),
        supabase.from('user_module_access').select('access_level').eq('profile_id', user.id).eq('module', 'logistica').maybeSingle()
      ])
      setProfile(prof)
      if (prof?.role === 'superadmin') setAccessLevel('admin')
      else setAccessLevel(access?.access_level || null)
    }
    init()
  }, [])
  
  useEffect(() => { if (accessLevel) loadAll() }, [accessLevel])
  
  const loadAll = async () => {
    setLoad(true)
    const [activeRes, catRes, kpiRes, rezRes, sitesRes, setariRes, kpiAlimRes, ultimeRes] = await Promise.all([
      supabase.from('logistica_active')
        .select('*, logistica_categorii(tip, subcategorie), logistica_mentenanta_plan(urmatoarea_data, urmatoarea_ore)')
        .order('marca', { ascending: true }).order('model', { ascending: true }),
      supabase.from('logistica_categorii').select('*').order('tip').order('subcategorie'),
      supabase.from('v_kpi_logistica').select('*').single(),
      supabase.from('logistica_rezervoare').select('*').eq('nume', 'Gazpet - Oscar').maybeSingle(),
      supabase.from('sites').select('id, name').order('name'),
      supabase.from('logistica_setari').select('key, value').in('key', ['pret_motorina_ron', 'pret_motorina_actualizat']),
      supabase.from('v_alimentari_kpi').select('*').single(),
      supabase.from('v_alimentari_ultima').select('*'),
    ])
    setActive(activeRes.data || [])
    setCategorii(catRes.data || [])
    setKpi(kpiRes.data || null)
    setRezervor(rezRes.data || null)
    setSites(sitesRes.data || [])
    const setariMap = Object.fromEntries((setariRes.data || []).map(s => [s.key, s.value]))
    setPretMotorina(setariMap.pret_motorina_ron || null)
    setPretMotorinaActualizat(setariMap.pret_motorina_actualizat || null)
    setKpiAlim(kpiAlimRes.data || null)
    // Map ultima alimentare per activ
    const map = {}
    ;(ultimeRes.data || []).forEach(u => { map[u.active_id] = u })
    setUltimeAlim(map)
    setLoad(false)
  }
  
  const handleSaved = () => { loadAll(); setModal(null) }
  
  // ─── Export Excel ──────────────────────────────────────────────────────────
  const exportExcel = () => {
    const header = ['Nr crt', 'Cod intern', 'Nr inventar', 'Plăcuță', 'Marcă', 'Model', 'Tip', 'Subcategorie', 'An', 'Stare', 'Carburant', 'Normă consum', 'Unitate', 'Firmă', 'Mentenanță următoare', 'Zile până la scadență', 'Observații']
    const rows = filtered.map((a, idx) => {
      const cat = a.logistica_categorii
      const ment = a.logistica_mentenanta_plan?.[0]
      const days = ment?.urmatoarea_data ? daysUntil(ment.urmatoarea_data) : null
      return [
        idx + 1,
        a.cod_intern || '',
        a.nr_inventar || '',
        a.nr_inmatriculare || '',
        a.marca || '',
        a.model || '',
        cat?.tip || '',
        cat?.subcategorie || '',
        a.an_fabricatie || '',
        a.stare === 'Functional' ? 'Funcțional' : a.stare === 'Nefunctional' ? 'Nefuncțional' : a.stare === 'In_service' || a.stare === 'Service' ? 'În service' : (a.stare || ''),
        a.tip_carburant || '',
        a.norma_consum || '',
        a.unitate_norma || '',
        a.firma_proprietara || '',
        ment?.urmatoarea_data ? new Date(ment.urmatoarea_data).toLocaleDateString('ro-RO') : '',
        days !== null ? days : '',
        a.observatii || '',
      ]
    })
    
    const aoa = [
      [`Listă Active Logistică — ${new Date().toLocaleDateString('ro-RO')}`],
      [`${filtered.length} active${filtered.length !== active.length ? ` (filtrat din ${active.length})` : ''}`],
      [],
      header,
      ...rows
    ]
    const ws = XLSX.utils.aoa_to_sheet(aoa)
    
    // Stiluri
    const titleStyle = { font: { bold: true, sz: 14, color: { rgb: 'E3B341' } } }
    const subtitleStyle = { font: { italic: true, sz: 10, color: { rgb: '8B949E' } } }
    const headerStyle = {
      fill: { fgColor: { rgb: '1F2937' } },
      font: { bold: true, color: { rgb: 'E3B341' }, sz: 10 },
      alignment: { horizontal: 'center', vertical: 'center' },
      border: { top: { style: 'thin', color: { rgb: '30363D' } }, bottom: { style: 'thin', color: { rgb: '30363D' } }, left: { style: 'thin', color: { rgb: '30363D' } }, right: { style: 'thin', color: { rgb: '30363D' } } }
    }
    
    // Aplic stiluri
    if (ws['A1']) ws['A1'].s = titleStyle
    if (ws['A2']) ws['A2'].s = subtitleStyle
    header.forEach((_, c) => {
      const a = XLSX.utils.encode_cell({ r: 3, c })
      if (ws[a]) ws[a].s = headerStyle
    })
    
    // Lățimi coloane
    ws['!cols'] = [
      { wch: 6 }, { wch: 10 }, { wch: 12 }, { wch: 13 }, { wch: 16 }, { wch: 22 }, { wch: 15 }, { wch: 18 },
      { wch: 6 }, { wch: 14 }, { wch: 11 }, { wch: 9 }, { wch: 8 }, { wch: 16 },
      { wch: 14 }, { wch: 9 }, { wch: 30 }
    ]
    
    // Merge cells pentru titlu
    ws['!merges'] = [
      { s: { r: 0, c: 0 }, e: { r: 0, c: 15 } },
      { s: { r: 1, c: 0 }, e: { r: 1, c: 15 } },
    ]
    
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, 'Active Logistică')
    
    const today = new Date().toISOString().split('T')[0]
    XLSX.writeFile(wb, `Logistica_Active_${today}.xlsx`)
    
    showToast(`✓ Exportat ${filtered.length} active`, 'success')
  }
  
  // ─── Template Excel pentru Alimentări ──────────────────────────────────────
  const downloadTemplateAlimentari = () => {
    const aoa = [
      ['📋 Template Alimentări Combustibil — Gazpet Logistică'],
      ['Completați coloanele de mai jos. Coloana A trebuie să fie codul intern (TST...) sau plăcuța din ERP.'],
      ['Datele se importă apoi prin butonul "📤 Import Excel" din modul Logistică.'],
      [],
      ['Cod intern SAU Plăcuță', 'Data alimentării (DD-MM-YYYY)', 'Cantitate (litri)', 'Ore bord la alim.', 'Km la alim.', 'Ore lucrate efectiv', 'Stație', 'Card combustibil', 'Cost total (RON)', 'Număr factură', 'Observații'],
      ['TST094', '01-05-2026', 50.5, 1250, '', 8, 'Petrom', '7059-XXXX-1234', 380.50, 'F-2026-0123', 'Alim. în drum spre Transgaz Orsova'],
      ['PH 99 GAZ', '03-05-2026', 40, '', 145000, 6, 'OMV', '7059-XXXX-5678', 305.00, '', ''],
    ]
    const ws = XLSX.utils.aoa_to_sheet(aoa)
    
    const titleStyle = { font: { bold: true, sz: 14, color: { rgb: 'E3B341' } } }
    const noteStyle = { font: { italic: true, sz: 10, color: { rgb: '8B949E' } } }
    const headerStyle = {
      fill: { fgColor: { rgb: '2D2A1A' } },
      font: { bold: true, color: { rgb: 'E3B341' }, sz: 10 },
      alignment: { horizontal: 'center', vertical: 'center', wrapText: true },
      border: { top: { style: 'thin', color: { rgb: '30363D' } }, bottom: { style: 'thin', color: { rgb: '30363D' } }, left: { style: 'thin', color: { rgb: '30363D' } }, right: { style: 'thin', color: { rgb: '30363D' } } }
    }
    const exampleStyle = { fill: { fgColor: { rgb: 'FFFCE0' } }, font: { italic: true, sz: 10, color: { rgb: '6E7681' } } }
    
    if (ws['A1']) ws['A1'].s = titleStyle
    if (ws['A2']) ws['A2'].s = noteStyle
    if (ws['A3']) ws['A3'].s = noteStyle
    
    const headerCells = ['A5','B5','C5','D5','E5','F5','G5','H5','I5','J5','K5']
    headerCells.forEach(a => { if (ws[a]) ws[a].s = headerStyle })
    
    // Stiluri exemplu (rândurile 6 și 7)
    for (let r = 5; r <= 6; r++) {
      for (let c = 0; c < 11; c++) {
        const a = XLSX.utils.encode_cell({ r, c })
        if (ws[a]) ws[a].s = exampleStyle
      }
    }
    
    ws['!cols'] = [
      { wch: 22 }, { wch: 18 }, { wch: 12 }, { wch: 14 }, { wch: 14 },
      { wch: 14 }, { wch: 14 }, { wch: 18 }, { wch: 13 }, { wch: 14 }, { wch: 30 }
    ]
    ws['!merges'] = [
      { s: { r: 0, c: 0 }, e: { r: 0, c: 10 } },
      { s: { r: 1, c: 0 }, e: { r: 1, c: 10 } },
      { s: { r: 2, c: 0 }, e: { r: 2, c: 10 } },
    ]
    
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, 'Alimentări')
    XLSX.writeFile(wb, 'Template_Alimentari_Logistica.xlsx')
    showToast('✓ Template descărcat — completați și importați înapoi', 'success')
  }
  
  // ─── Import alimentări din Excel ───────────────────────────────────────────
  const [importPreview, setImportPreview] = useState(null)  // { rows: [...], errors: [...] }
  const fileInputRef = useState({ current: null })
  
  const handleImportFile = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    
    try {
      const buffer = await file.arrayBuffer()
      const wb = XLSX.read(buffer, { type: 'array', cellDates: true })
      const ws = wb.Sheets[wb.SheetNames[0]]
      const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, blankrows: false, raw: false })
      
      // Caut rândul cu header (cel cu "Cod intern" sau "Cantitate")
      let headerRow = -1
      for (let i = 0; i < Math.min(aoa.length, 10); i++) {
        const row = (aoa[i] || []).map(x => String(x || '').toLowerCase())
        if (row.some(c => c.includes('cantitate')) && row.some(c => c.includes('cod') || c.includes('plăcuță') || c.includes('placuta'))) {
          headerRow = i; break
        }
      }
      if (headerRow === -1) { showToast('Nu am găsit antetul în fișier. Folosește template-ul oficial!', 'error'); e.target.value = ''; return }
      
      const dataRows = aoa.slice(headerRow + 1).filter(r => r && r.length > 0 && (r[0] || r[1] || r[2]))
      
      const rows = []
      const errors = []
      
      dataRows.forEach((r, idx) => {
        const codOrPlate = String(r[0] || '').trim()
        const data = r[1]
        const cantitate = r[2]
        
        if (!codOrPlate) return  // skip exemple goale
        
        // Match activ
        const matched = active.find(a => 
          a.cod_intern?.toLowerCase() === codOrPlate.toLowerCase() ||
          a.nr_inmatriculare?.toLowerCase() === codOrPlate.toLowerCase() ||
          a.nr_inventar?.toLowerCase() === codOrPlate.toLowerCase()
        )
        
        if (!matched) {
          errors.push(`Rând ${idx + headerRow + 2}: Activ negăsit pentru "${codOrPlate}"`)
          return
        }
        if (!cantitate || isNaN(Number(cantitate)) || Number(cantitate) <= 0) {
          errors.push(`Rând ${idx + headerRow + 2}: Cantitate invalidă pentru "${codOrPlate}"`)
          return
        }
        
        // Parsare data
        let dataAlim
        if (data instanceof Date) {
          dataAlim = data.toISOString().split('T')[0]
        } else if (typeof data === 'string') {
          // încercăm DD-MM-YYYY sau DD/MM/YYYY sau YYYY-MM-DD
          const m = data.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/)
          if (m) {
            dataAlim = `${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`
          } else if (/^\d{4}-\d{2}-\d{2}/.test(data)) {
            dataAlim = data.substring(0, 10)
          } else {
            errors.push(`Rând ${idx + headerRow + 2}: Data invalidă "${data}"`)
            return
          }
        } else {
          errors.push(`Rând ${idx + headerRow + 2}: Data lipsă`)
          return
        }
        
        rows.push({
          active_id: matched.id,
          activ_label: `${matched.cod_intern || matched.nr_inmatriculare} · ${matched.marca || ''} ${matched.model || ''}`.trim(),
          data_alimentare: dataAlim,
          cantitate_litri: Number(cantitate),
          ore_la_alimentare: r[3] ? Number(r[3]) : null,
          km_la_alimentare: r[4] ? Number(r[4]) : null,
          ore_lucrate_efectiv: r[5] ? Number(r[5]) : null,
          statie_combustibil: r[6] ? String(r[6]).trim() : null,
          card_combustibil: r[7] ? String(r[7]).trim() : null,
          pret_total: r[8] ? Number(r[8]) : null,
          numar_factura: r[9] ? String(r[9]).trim() : null,
          observatii: r[10] ? String(r[10]).trim() : null,
        })
      })
      
      setImportPreview({ rows, errors, fileName: file.name })
      e.target.value = ''
    } catch (err) {
      console.error(err)
      showToast(`Eroare la citire: ${err.message}`, 'error')
      e.target.value = ''
    }
  }
  
  const handleImportConfirm = async () => {
    if (!importPreview?.rows?.length) return
    const { data: { user } } = await supabase.auth.getUser()
    
    const payload = importPreview.rows.map(r => {
      const { activ_label, ...rest } = r
      return { ...rest, pret_per_litru: r.pret_total && r.cantitate_litri ? Number((r.pret_total / r.cantitate_litri).toFixed(4)) : null, created_by: user?.id }
    })
    
    const { error } = await supabase.from('logistica_alimentari').insert(payload)
    if (error) { showToast(`Eroare import: ${error.message}`, 'error'); return }
    
    showToast(`✓ Import reușit: ${payload.length} alimentări`, 'success')
    setImportPreview(null)
    loadAll()
  }
  
  const tipuri = useMemo(() => ['Toate', ...Array.from(new Set(categorii.map(c => c.tip))).sort()], [categorii])
  const subcategoriiPentruTip = useMemo(() => {
    if (tipF === 'Toate') return []
    const subs = categorii.filter(c => c.tip === tipF && c.subcategorie).map(c => c.subcategorie)
    return ['Toate', ...subs.sort()]
  }, [tipF, categorii])
  
  const filtered = useMemo(() => {
    const result = active.filter(a => {
      const cat = a.logistica_categorii
      if (search) {
        const s = search.toLowerCase()
        const haystack = [a.cod_intern, a.nr_inventar, a.nr_inmatriculare, a.marca, a.model, a.observatii, cat?.tip, cat?.subcategorie].filter(Boolean).join(' ').toLowerCase()
        if (!haystack.includes(s)) return false
      }
      if (tipF !== 'Toate' && cat?.tip !== tipF) return false
      if (subF !== 'Toate' && cat?.subcategorie !== subF) return false
      if (stareF !== 'Toate' && a.stare !== stareF) return false
      return true
    })
    
    // Sortare
    const dir = sortBy.dir === 'asc' ? 1 : -1
    const getValue = (a) => {
      const cat = a.logistica_categorii
      const ment = a.logistica_mentenanta_plan?.[0]
      switch(sortBy.col) {
        case 'cod_intern': return a.cod_intern || 'zzz'
        case 'nr_inventar': return a.nr_inventar || 'zzz'
        case 'nr_inmatriculare': return a.nr_inmatriculare || 'zzz'
        case 'marca': return [(a.marca || 'zzz').toLowerCase(), (a.model || '').toLowerCase()].join(' ')
        case 'tip': return [(cat?.tip || 'zzz').toLowerCase(), (cat?.subcategorie || '').toLowerCase()].join(' ')
        case 'an': return a.an_fabricatie || 0
        case 'stare': return a.stare || 'zzz'
        case 'mentenanta': return ment?.urmatoarea_data ? new Date(ment.urmatoarea_data).getTime() : 9999999999999
        default: return ''
      }
    }
    result.sort((a, b) => {
      const va = getValue(a), vb = getValue(b)
      if (typeof va === 'number' && typeof vb === 'number') return (va - vb) * dir
      return String(va).localeCompare(String(vb), 'ro') * dir
    })
    return result
  }, [active, search, tipF, subF, stareF, sortBy])
  
  // Calculez alerte mentenanță (pentru widget)
  const alerteMentenanta = useMemo(() => {
    const intarziate = []
    const urgente = []  // <= 7 zile
    const apropiate = []  // 8-30 zile
    active.forEach(a => {
      const ment = a.logistica_mentenanta_plan?.[0]
      if (!ment?.urmatoarea_data) return
      const days = daysUntil(ment.urmatoarea_data)
      if (days === null) return
      if (days < 0) intarziate.push(a)
      else if (days <= 7) urgente.push(a)
      else if (days <= 30) apropiate.push(a)
    })
    return { intarziate, urgente, apropiate }
  }, [active])
  
  if (accessLevel === undefined) return <div style={{...S.page, display: 'flex', alignItems: 'center', justifyContent: 'center'}}><div className="sp" style={{width: 28, height: 28}}/></div>
  
  if (accessLevel === null) return (
    <div style={{...S.page, padding: '60px 32px', textAlign: 'center'}}>
      <div style={{fontSize: 80, marginBottom: 16}}>🔒</div>
      <div style={{fontSize: 20, fontWeight: 800, color: G.text, marginBottom: 8}}>Acces interzis</div>
      <div style={{fontSize: 14, color: G.muted, marginBottom: 24}}>
        Nu ai permisiunea de a accesa modulul Logistică.<br/>
        Contactează administratorul pentru acces.
      </div>
      <button onClick={() => nav('/')} style={S.btnP}>← Înapoi la Acasă</button>
    </div>
  )
  
  const canEdit = accessLevel === 'admin' || accessLevel === 'editor'
  
  return (
    <>
      <Toast toast={toast}/>
      
      <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14, flexWrap: 'wrap', gap: 12}}>
        <div>
          <div style={{display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4}}>
            <span style={{fontSize: 24}}>🚛</span>
            <div style={{fontSize: 22, fontWeight: 800, color: G.text}}>Logistică</div>
            <span style={{fontSize: 10, fontWeight: 700, padding: '3px 8px', borderRadius: 4, background: G.logistica + '22', color: G.logistica, letterSpacing: '.4px'}}>
              {accessLevel === 'admin' ? '⚙ ADMIN' : accessLevel === 'editor' ? '✎ EDITOR' : '👁 VIEWER'}
            </span>
          </div>
          <div style={{fontSize: 12, color: G.muted}}>
            {filtered.length}{filtered.length !== active.length ? ` din ${active.length}` : ''} active · {profile?.name}
          </div>
        </div>
      </div>
      
      {/* Bara de tab-uri */}
      <TabsBar tab={tab} setTab={setTab} />
      
      {/* TAB: Alimentări (input bulk per zi) */}
      {tab === 'alimentari' && (
        <AlimentariBulkPage 
          active={active}
          ultimeAlim={ultimeAlim}
          sites={sites}
          rezervorGazpet={rezervor}
          pretMotorina={pretMotorina}
          dataAlim={dataAlim}
          setDataAlim={setDataAlim}
          canEdit={canEdit}
          showToast={showToast}
          onSaved={loadAll}
        />
      )}
      
      {/* TAB: Documente — 4 sub-taburi (Flotă · Personal · AMC · Alerte) */}
      {tab === 'documente' && (
        <DocumenteTab 
          active={active} 
          accessLevel={accessLevel} 
          profile={profile}
          showToast={showToast}
        />
      )}
      
      {/* TAB: Service (Fișe service detaliate) */}
      {tab === 'service' && <ServiceTab active={active} canEdit={canEdit} showToast={showToast} />}
      
      {/* TAB: Tichete (placeholder) */}
      {tab === 'tichete' && <PlaceholderTab label="Tichete" desc="Avarii · Defecțiuni · Reclamații · Rezolvări" emoji="🎫" />}
      
      {/* TAB: Active (default — conținutul existent) */}
      {tab === 'lista' && (<>
      
      {kpi && (
        <div style={{display: 'flex', gap: 12, marginBottom: 14, flexWrap: 'wrap'}}>
          <KPICard icon="🚛" label="Total active" value={kpi.nr_total_active} color={G.blue} />
          <KPICard icon="✓" label="Funcționale" value={kpi.nr_functionale} color={G.green} sub={`${kpi.procent_functionale}%`} />
          <KPICard icon="✗" label="Nefuncționale" value={kpi.nr_nefunctionale} color={G.red} />
          <KPICard icon="🔧" label="În service" value={kpi.nr_in_service} color={G.yellow} />
          <KPICard icon="📅" label="Scadențe 30z" value={kpi.nr_scadente_30_zile} color={G.orange} />
          <KPICard icon="📄" label="Doc. expirate" value={kpi.nr_documente_expirate} color={G.red} />
        </div>
      )}
      
      {/* Widget Rezervor Gazpet + Preț motorină */}
      <div style={{display: 'flex', gap: 12, marginBottom: 14, flexWrap: 'wrap'}}>
        {rezervor && (() => {
          const stoc = Number(rezervor.stoc_curent_litri || 0)
          const cap = Number(rezervor.capacitate_litri || 0)
          const pragProc = Number(rezervor.prag_alerta_procent || 10)
          const pragLitri = cap * pragProc / 100
          const procentUmplere = cap > 0 ? (stoc / cap) * 100 : 0
          const isLow = stoc <= pragLitri
          const isCritic = stoc <= pragLitri / 2
          
          let barColor, statusText, statusColor
          if (isCritic) { barColor = G.red; statusText = '🚨 STOC CRITIC — comandă urgent!'; statusColor = G.red }
          else if (isLow) { barColor = G.orange; statusText = '⚠️ Sub pragul de alertă'; statusColor = G.orange }
          else if (procentUmplere > 90) { barColor = G.green; statusText = '✓ Rezervor plin'; statusColor = G.green }
          else { barColor = G.blue; statusText = '✓ Stoc normal'; statusColor = G.blue }
          
          return (
            <div style={{...S.card, padding: '12px 16px', flex: 2, minWidth: 360, borderLeft: `3px solid ${barColor}`}}>
              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8}}>
                <div>
                  <div style={{fontSize: 11, color: G.muted, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.5px'}}>
                    📦 {rezervor.nume}
                  </div>
                  <div style={{fontSize: 22, fontWeight: 800, color: G.text, fontVariantNumeric: 'tabular-nums', marginTop: 2}}>
                    {stoc.toLocaleString('ro-RO', {minimumFractionDigits: 1, maximumFractionDigits: 1})} <span style={{fontSize: 12, color: G.muted, fontWeight: 600}}>L</span>
                    <span style={{fontSize: 12, color: G.muted, fontWeight: 600, marginLeft: 8}}>/ {cap.toFixed(0)} L</span>
                  </div>
                </div>
                {canEdit && (
                  <div style={{display: 'flex', gap: 6}}>
                    <button onClick={() => setShowEditStoc(true)} style={{...S.btnS, fontSize: 11, color: G.yellow, borderColor: G.yellow + '55', padding: '5px 10px'}} title="Ajustare manuală stoc (corecții)">
                      ✏️ Edit
                    </button>
                    <button onClick={() => setShowAchizitie(true)} style={{...S.btnS, fontSize: 11, color: G.purple, borderColor: G.purple + '55', padding: '5px 10px'}}>
                      + Achiziție vrac
                    </button>
                  </div>
                )}
              </div>
              <div style={{height: 8, background: G.bg, borderRadius: 4, overflow: 'hidden', marginBottom: 6}}>
                <div style={{
                  width: `${Math.min(procentUmplere, 100)}%`,
                  height: '100%',
                  background: barColor,
                  transition: 'width .3s'
                }}/>
              </div>
              <div style={{display: 'flex', justifyContent: 'space-between', fontSize: 11}}>
                <span style={{color: statusColor, fontWeight: 600}}>{statusText}</span>
                <span style={{color: G.muted}}>{procentUmplere.toFixed(0)}% · prag alertă: {pragProc}%</span>
              </div>
            </div>
          )
        })()}
        
        {/* Card preț motorină */}
        <div style={{...S.card, padding: '12px 16px', flex: 1, minWidth: 200, borderLeft: `3px solid ${G.green}`}}>
          <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 4}}>
            <div style={{fontSize: 11, color: G.muted, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.5px'}}>
              💰 Preț motorină
            </div>
            {canEdit && (
              <button onClick={() => setShowSetariPret(true)} style={{background:'transparent', border:'none', color:G.muted, fontSize: 14, cursor:'pointer', padding: 0, lineHeight: 1}} title="Editează preț">⚙️</button>
            )}
          </div>
          <div style={{fontSize: 22, fontWeight: 800, color: G.green, fontVariantNumeric: 'tabular-nums'}}>
            {pretMotorina ? Number(pretMotorina).toFixed(2) : '—'} <span style={{fontSize: 12, color: G.muted, fontWeight: 600}}>RON/L</span>
          </div>
          <div style={{fontSize: 10, color: G.muted, marginTop: 2}}>
            actualizat: {pretMotorinaActualizat || '—'}
          </div>
        </div>
      </div>
      
      {/* Widget statistici alimentări — IERI / ULTIMELE 7 ZILE / LUNA */}
      {kpiAlim && (
        <div style={{display: 'flex', gap: 12, marginBottom: 14, flexWrap: 'wrap'}}>
          <PerioadaCard label="📅 Ieri" data={kpiAlim} suffix="ieri" color={G.blue} />
          <PerioadaCard label="📊 Ultimele 7 zile" data={kpiAlim} suffix="saptamana" color={G.purple} />
          <PerioadaCard label="📆 Luna curentă" data={kpiAlim} suffix="luna" color={G.orange} />
        </div>
      )}
      {(alerteMentenanta.intarziate.length > 0 || alerteMentenanta.urgente.length > 0) && (
        <div style={{
          ...S.card,
          padding: '12px 16px',
          marginBottom: 14,
          borderLeft: `4px solid ${alerteMentenanta.intarziate.length > 0 ? G.red : G.orange}`,
          background: alerteMentenanta.intarziate.length > 0 ? G.redDim + '88' : G.yellowDim + '88',
        }}>
          <div style={{display: 'flex', alignItems: 'center', gap: 14, flexWrap: 'wrap'}}>
            <div style={{fontSize: 22}}>
              {alerteMentenanta.intarziate.length > 0 ? '⚠️' : '🔔'}
            </div>
            <div style={{flex: 1}}>
              <div style={{fontSize: 13, fontWeight: 700, color: G.text, marginBottom: 2}}>
                Atenție — mentenanță urgentă
              </div>
              <div style={{fontSize: 12, color: G.muted, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
                {alerteMentenanta.intarziate.length > 0 && (
                  <span style={{color: G.red, fontWeight: 600}}>
                    🔴 {alerteMentenanta.intarziate.length} întârziate
                  </span>
                )}
                {alerteMentenanta.urgente.length > 0 && (
                  <span style={{color: G.orange, fontWeight: 600}}>
                    🟠 {alerteMentenanta.urgente.length} în următoarele 7 zile
                  </span>
                )}
                {alerteMentenanta.apropiate.length > 0 && (
                  <span style={{color: G.yellow, fontWeight: 600}}>
                    🟡 {alerteMentenanta.apropiate.length} în 8-30 zile
                  </span>
                )}
              </div>
            </div>
            <button 
              onClick={() => setSortBy({ col: 'mentenanta', dir: 'asc' })}
              style={{...S.btnS, fontSize: 12, color: G.logistica, borderColor: G.logistica + '55'}}>
              📅 Sortează după scadență
            </button>
          </div>
        </div>
      )}
      
      <div style={{...S.card, padding: 14, marginBottom: 14}}>
        <div style={{display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center'}}>
          <input placeholder="🔍 Caută marcă, model, plăcuță, cod..." value={search} onChange={e => setSearch(e.target.value)} style={{...S.input, width: 280}}/>
          <select value={tipF} onChange={e => { setTipF(e.target.value); setSubF('Toate') }}>
            {tipuri.map(t => <option key={t} value={t}>{t === 'Toate' ? 'Toate tipurile' : t}</option>)}
          </select>
          {subcategoriiPentruTip.length > 0 && (
            <select value={subF} onChange={e => setSubF(e.target.value)}>
              {subcategoriiPentruTip.map(s => <option key={s} value={s}>{s === 'Toate' ? 'Toate subcategoriile' : s}</option>)}
            </select>
          )}
          <select value={stareF} onChange={e => setStareF(e.target.value)}>
            <option value="Toate">Toate stările</option>
            <option value="Functional">Funcțional</option>
            <option value="Nefunctional">Nefuncțional</option>
            <option value="In_service">În service</option>
          </select>
          {(search || tipF !== 'Toate' || subF !== 'Toate' || stareF !== 'Toate') && (
            <button onClick={() => { setSearch(''); setTipF('Toate'); setSubF('Toate'); setStareF('Toate') }} style={{...S.btnS, fontSize: 12, color: G.muted}}>
              ✕ Șterge filtre
            </button>
          )}
          <div style={{flex: 1}}/>
          <button onClick={downloadTemplateAlimentari} style={{...S.btnS, fontSize: 12, color: G.muted, borderColor: G.border}} title="Template Excel pentru șefii de echipă">
            📋 Template
          </button>
          {canEdit && (
            <label style={{...S.btnS, fontSize: 12, color: G.orange, borderColor: G.orange + '55', cursor: 'pointer', display: 'inline-flex', alignItems: 'center'}}>
              📤 Import alimentări
              <input type="file" accept=".xlsx,.xls" onChange={handleImportFile} style={{display: 'none'}} />
            </label>
          )}
          <button onClick={exportExcel} disabled={filtered.length === 0} style={{...S.btnS, fontSize: 12, color: G.green, borderColor: G.green + '55', opacity: filtered.length === 0 ? .4 : 1}}>
            📥 Excel
          </button>
          {canEdit && (
            <button onClick={() => setModal({ mode: 'create', activ: null })} style={{...S.btnP, background: G.logistica, color: '#000'}}>
              + Activ nou
            </button>
          )}
        </div>
      </div>
      
      {load ? (
        <div style={{display: 'flex', justifyContent: 'center', padding: 80}}><div className="sp" style={{width: 32, height: 32}}/></div>
      ) : filtered.length === 0 ? (
        <div style={{...S.card, padding: 60, textAlign: 'center', color: G.muted}}>
          <div style={{fontSize: 40, marginBottom: 12}}>🔍</div>
          <div style={{fontSize: 14}}>Niciun activ găsit cu filtrele aplicate</div>
        </div>
      ) : (
        <div style={{...S.card, overflow: 'hidden'}}>
          <div style={{overflowX: 'auto'}}>
            <table>
              <thead>
                <tr>
                  <th style={{width: 45, padding: '10px 8px', textAlign: 'center', color: G.muted, fontWeight: 700, fontSize: 11, textTransform: 'uppercase', letterSpacing: '.4px'}}>#</th>
                  <SortableTh col="cod_intern" sortBy={sortBy} setSortBy={setSortBy} width={75}>Cod intern</SortableTh>
                  <SortableTh col="nr_inventar" sortBy={sortBy} setSortBy={setSortBy} width={90}>Nr inventar</SortableTh>
                  <SortableTh col="nr_inmatriculare" sortBy={sortBy} setSortBy={setSortBy} width={95}>Plăcuță</SortableTh>
                  <SortableTh col="marca" sortBy={sortBy} setSortBy={setSortBy}>Marcă · Model</SortableTh>
                  <SortableTh col="tip" sortBy={sortBy} setSortBy={setSortBy} width={170}>Categorie</SortableTh>
                  <SortableTh col="an" sortBy={sortBy} setSortBy={setSortBy} width={60}>An</SortableTh>
                  <SortableTh col="stare" sortBy={sortBy} setSortBy={setSortBy} width={120}>Stare</SortableTh>
                  <SortableTh col="mentenanta" sortBy={sortBy} setSortBy={setSortBy} width={150}>Mentenanță</SortableTh>
                  <th style={{width: 50}}></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((a, idx) => {
                  const cat = a.logistica_categorii
                  const ment = a.logistica_mentenanta_plan?.[0]
                  return (
                    <tr key={a.id} onClick={() => setModal({ mode: 'view', activ: a })} style={{cursor: 'pointer'}}>
                      <td style={{textAlign: 'center', fontFamily: 'monospace', fontSize: 11, color: G.muted, fontWeight: 600}}>
                        {idx + 1}
                      </td>
                      <td style={{fontFamily: 'monospace', fontSize: 12, color: G.blue, fontWeight: 600}}>
                        {a.cod_intern || <span style={{color: G.dim}}>—</span>}
                      </td>
                      <td style={{fontFamily: 'monospace', fontSize: 11, color: G.muted}}>
                        {a.nr_inventar || <span style={{color: G.dim}}>—</span>}
                      </td>
                      <td style={{fontSize: 12, fontWeight: 600, color: G.purple}}>
                        {a.nr_inmatriculare || <span style={{color: G.dim, fontWeight: 400}}>—</span>}
                      </td>
                      <td>
                        <div style={{fontWeight: 600, color: G.text}}>
                          {a.marca || <span style={{color: G.dim, fontWeight: 400}}>—</span>}
                        </div>
                        <div style={{fontSize: 11, color: G.muted, marginTop: 1}}>{a.model}</div>
                      </td>
                      <td>
                        {cat ? (
                          <div>
                            <div style={{fontSize: 12, fontWeight: 600, color: G.text}}>{cat.tip}</div>
                            {cat.subcategorie && <div style={{fontSize: 11, color: G.muted, marginTop: 1}}>{cat.subcategorie}</div>}
                          </div>
                        ) : <span style={{color: G.dim}}>—</span>}
                      </td>
                      <td style={{fontVariantNumeric: 'tabular-nums', color: G.muted, fontSize: 12}}>
                        {a.an_fabricatie || '—'}
                      </td>
                      <td><StareBadge stare={a.stare} /></td>
                      <td><MentenantaScadenta data={ment?.urmatoarea_data} ore={ment?.urmatoarea_ore} /></td>
                      <td style={{textAlign: 'center', color: G.dim}}>›</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
          <div style={{padding: '10px 14px', borderTop: `1px solid ${G.border}`, fontSize: 11, color: G.muted, background: G.bg}}>
            {filtered.length} active afișate · click pe rând pentru detalii{canEdit ? ' / editare' : ''}
          </div>
        </div>
      )}
      
      </>)}
      
      {modal && (
        <ActivFormModal 
          activ={modal.activ}
          initialMode={modal.mode}
          categorii={categorii}
          accessLevel={accessLevel}
          rezervorGazpet={rezervor}
          sites={sites}
          pretMotorina={pretMotorina}
          onClose={() => setModal(null)}
          onSaved={handleSaved}
          showToast={showToast}
        />
      )}
      
      {/* Modal achiziție vrac */}
      {showAchizitie && rezervor && (
        <AchizitieVracModal 
          rezervor={rezervor}
          onClose={() => setShowAchizitie(false)}
          onSaved={() => { setShowAchizitie(false); loadAll() }}
          showToast={showToast}
        />
      )}
      
      {/* Modal edit stoc rezervor (corecții manuale) */}
      {showEditStoc && rezervor && (
        <EditStocModal 
          rezervor={rezervor}
          onClose={() => setShowEditStoc(false)}
          onSaved={() => { setShowEditStoc(false); loadAll() }}
          showToast={showToast}
        />
      )}
      
      {/* Modal setări preț motorină */}
      {showSetariPret && (
        <SetariMotorinaModal 
          pret={pretMotorina}
          dataActualizat={pretMotorinaActualizat}
          onClose={() => setShowSetariPret(false)}
          onSaved={() => { setShowSetariPret(false); loadAll() }}
          showToast={showToast}
        />
      )}
      
      {/* Modal Import Preview */}
      {importPreview && (
        <div onClick={() => setImportPreview(null)} style={{position:'fixed', inset:0, background:'#000000cc', zIndex:300, display:'flex', alignItems:'flex-start', justifyContent:'center', padding:'30px 16px', overflowY:'auto'}}>
          <div onClick={e => e.stopPropagation()} style={{...S.card, padding: 20, width: '100%', maxWidth: 880, boxShadow: '0 20px 80px rgba(0,0,0,.6)', borderTop: `3px solid ${G.orange}`}} className="fi">
            <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom: 14, paddingBottom: 12, borderBottom: `1px solid ${G.border}`}}>
              <div>
                <div style={{fontSize: 17, fontWeight: 800, color: G.text, marginBottom: 4}}>
                  📤 Import alimentări — preview
                </div>
                <div style={{fontSize: 12, color: G.muted}}>
                  Fișier: <strong style={{color: G.text}}>{importPreview.fileName}</strong> · 
                  <span style={{color: G.green, marginLeft: 6}}>{importPreview.rows.length} ok</span>
                  {importPreview.errors.length > 0 && <span style={{color: G.red, marginLeft: 6}}>· {importPreview.errors.length} cu probleme</span>}
                </div>
              </div>
              <button onClick={() => setImportPreview(null)} style={{background:'transparent', border:'none', color:G.muted, fontSize: 22, cursor:'pointer', padding: 4}}>×</button>
            </div>
            
            {importPreview.errors.length > 0 && (
              <div style={{...S.card, padding: 10, marginBottom: 12, background: G.redDim + '88', borderColor: G.red + '55'}}>
                <div style={{fontSize: 12, fontWeight: 700, color: G.red, marginBottom: 6}}>⚠️ Probleme detectate (rândurile vor fi sărite):</div>
                <ul style={{margin: 0, paddingLeft: 20, fontSize: 11, color: G.muted}}>
                  {importPreview.errors.slice(0, 10).map((e, i) => <li key={i}>{e}</li>)}
                  {importPreview.errors.length > 10 && <li>... și încă {importPreview.errors.length - 10} probleme</li>}
                </ul>
              </div>
            )}
            
            {importPreview.rows.length > 0 ? (
              <div style={{...S.card, overflow: 'hidden', marginBottom: 14, maxHeight: 400, overflowY: 'auto'}}>
                <table>
                  <thead>
                    <tr>
                      <th style={{width: 90}}>Data</th>
                      <th>Activ</th>
                      <th style={{width: 70}}>Cantit.</th>
                      <th style={{width: 90}}>Stație</th>
                      <th style={{width: 80}}>Cost</th>
                    </tr>
                  </thead>
                  <tbody>
                    {importPreview.rows.slice(0, 50).map((r, i) => (
                      <tr key={i}>
                        <td style={{fontFamily: 'monospace', fontSize: 12}}>{fmtDate(r.data_alimentare)}</td>
                        <td style={{fontSize: 12, color: G.text}}>{r.activ_label}</td>
                        <td style={{fontSize: 12, color: G.orange, fontWeight: 700}}>{r.cantitate_litri} L</td>
                        <td style={{fontSize: 11, color: G.muted}}>{r.statie_combustibil || '—'}</td>
                        <td style={{fontSize: 12, color: G.green, fontWeight: 600}}>{r.pret_total ? `${Number(r.pret_total).toFixed(2)} RON` : '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {importPreview.rows.length > 50 && (
                  <div style={{padding: 10, textAlign: 'center', fontSize: 11, color: G.muted, background: G.bg, borderTop: `1px solid ${G.border}`}}>
                    ... și încă {importPreview.rows.length - 50} înregistrări (toate vor fi importate)
                  </div>
                )}
              </div>
            ) : (
              <div style={{padding: 30, textAlign: 'center', color: G.muted}}>Nicio înregistrare validă de importat</div>
            )}
            
            <div style={{display:'flex', justifyContent:'flex-end', gap: 8, paddingTop: 12, borderTop: `1px solid ${G.border}`}}>
              <button onClick={() => setImportPreview(null)} style={{...S.btnS, fontSize: 13, color: G.muted}}>Anulează</button>
              <button onClick={handleImportConfirm} disabled={importPreview.rows.length === 0} style={{...S.btnP, background: G.orange, opacity: importPreview.rows.length === 0 ? .4 : 1}}>
                ✓ Importă {importPreview.rows.length} alimentări
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
